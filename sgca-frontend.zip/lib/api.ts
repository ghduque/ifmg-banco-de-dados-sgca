// Simulação da API - Em produção, substituir por chamadas reais
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api'

class ApiService {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`
    
    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
        ...options,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error('API request failed:', error)
      throw error
    }
  }

  // Anos Letivos
  async getAnosLetivos() {
    return this.request('/anos-letivos')
  }

  async createAnoLetivo(data: any) {
    return this.request('/anos-letivos', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updateAnoLetivo(id: string, data: any) {
    return this.request(`/anos-letivos/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deleteAnoLetivo(id: string) {
    return this.request(`/anos-letivos/${id}`, {
      method: 'DELETE',
    })
  }

  // Calendários
  async getCalendarios(anoLetivoId?: string) {
    const query = anoLetivoId ? `?anoLetivoId=${anoLetivoId}` : ''
    return this.request(`/calendarios${query}`)
  }

  async createCalendario(data: any) {
    return this.request('/calendarios', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updateCalendario(id: string, data: any) {
    return this.request(`/calendarios/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deleteCalendario(id: string) {
    return this.request(`/calendarios/${id}`, {
      method: 'DELETE',
    })
  }

  // Categorias de Datas
  async getCategoriasDatas(calendarioId?: string) {
    const query = calendarioId ? `?calendarioId=${calendarioId}` : ''
    return this.request(`/categorias-datas${query}`)
  }

  async createCategoriaData(data: any) {
    return this.request('/categorias-datas', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updateCategoriaData(id: string, data: any) {
    return this.request(`/categorias-datas/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deleteCategoriaData(id: string) {
    return this.request(`/categorias-datas/${id}`, {
      method: 'DELETE',
    })
  }

  // Datas
  async getDatas(categoriaDataId?: string) {
    const query = categoriaDataId ? `?categoriaDataId=${categoriaDataId}` : ''
    return this.request(`/datas${query}`)
  }

  async createData(data: any) {
    return this.request('/datas', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updateData(id: string, data: any) {
    return this.request(`/datas/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deleteData(id: string) {
    return this.request(`/datas/${id}`, {
      method: 'DELETE',
    })
  }

  // Reposições
  async getReposicoes(calendarioId?: string) {
    const query = calendarioId ? `?calendarioId=${calendarioId}` : ''
    return this.request(`/reposicoes${query}`)
  }

  async createReposicao(data: any) {
    return this.request('/reposicoes', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updateReposicao(id: string, data: any) {
    return this.request(`/reposicoes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deleteReposicao(id: string) {
    return this.request(`/reposicoes/${id}`, {
      method: 'DELETE',
    })
  }

  // Eventos Obrigatórios
  async getEventosObrigatorios() {
    return this.request('/eventos-obrigatorios')
  }

  async createEventoObrigatorio(data: any) {
    return this.request('/eventos-obrigatorios', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updateEventoObrigatorio(id: string, data: any) {
    return this.request(`/eventos-obrigatorios/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deleteEventoObrigatorio(id: string) {
    return this.request(`/eventos-obrigatorios/${id}`, {
      method: 'DELETE',
    })
  }

  // Prazos e Eventos
  async getPrazosEventos(anoLetivoId?: string) {
    const query = anoLetivoId ? `?anoLetivoId=${anoLetivoId}` : ''
    return this.request(`/prazos-eventos${query}`)
  }

  async createPrazoEvento(data: any) {
    return this.request('/prazos-eventos', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  async updatePrazoEvento(id: string, data: any) {
    return this.request(`/prazos-eventos/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  async deletePrazoEvento(id: string) {
    return this.request(`/prazos-eventos/${id}`, {
      method: 'DELETE',
    })
  }

  // Equalização
  async getDiasLetivos(calendarioId: string) {
    return this.request(`/equalizacao/dias-letivos/${calendarioId}`)
  }
}

export const api = new ApiService()
