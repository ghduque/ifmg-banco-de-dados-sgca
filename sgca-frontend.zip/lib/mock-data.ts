import type { AnoLetivo, Calendario, CategoriaData, Data, EventoObrigatorio, PrazoEvento, Reposicao } from '@/types'

// Dados mockados para desenvolvimento
export const mockAnosLetivos: AnoLetivo[] = [
  {
    id: '1',
    ano: 2024,
    descricao: 'Ano Letivo 2024',
    dataInicio: '2024-02-01',
    dataFim: '2024-12-20',
    pendencias: []
  },
  {
    id: '2',
    ano: 2025,
    descricao: 'Ano Letivo 2025',
    dataInicio: '2025-02-01',
    dataFim: '2025-12-20',
    pendencias: ['Calendário não sincronizado']
  }
]

export const mockCalendarios: Calendario[] = [
  {
    id: '1',
    anoLetivoId: '1',
    nome: 'Calendário Principal 2024',
    sincronizado: true,
    pendencias: []
  },
  {
    id: '2',
    anoLetivoId: '2',
    nome: 'Calendário Principal 2025',
    sincronizado: false,
    pendencias: ['Faltam categorias de datas']
  }
]

export const mockCategoriasDatas: CategoriaData[] = [
  {
    id: '1',
    calendarioId: '1',
    nome: 'Aulas',
    cor: '#3b82f6',
    numeroMinimoDias: 200,
    datasLetivas: true,
    diasSemanaValidos: [false, true, true, true, true, true, false]
  },
  {
    id: '2',
    calendarioId: '1',
    nome: 'Férias',
    cor: '#ef4444',
    numeroMinimoDias: 0,
    datasLetivas: false,
    diasSemanaValidos: [true, true, true, true, true, true, true]
  },
  {
    id: '3',
    calendarioId: '1',
    nome: 'Provas',
    cor: '#f59e0b',
    numeroMinimoDias: 10,
    datasLetivas: true,
    diasSemanaValidos: [false, true, true, true, true, true, false]
  }
]

export const mockDatas: Data[] = [
  {
    id: '1',
    categoriaDataId: '1',
    descricao: '1º Semestre',
    inicio: '2024-02-01',
    fim: '2024-06-30',
    diasFaltantes: 0
  },
  {
    id: '2',
    categoriaDataId: '1',
    descricao: '2º Semestre',
    inicio: '2024-08-01',
    fim: '2024-12-20',
    diasFaltantes: 5
  },
  {
    id: '3',
    categoriaDataId: '2',
    descricao: 'Férias de Julho',
    inicio: '2024-07-01',
    fim: '2024-07-31'
  }
]

export const mockEventosObrigatorios: EventoObrigatorio[] = [
  {
    id: '1',
    descricao: 'Reunião Pedagógica',
    numeroOcorrencias: 4
  },
  {
    id: '2',
    descricao: 'Conselho de Classe',
    numeroOcorrencias: 2
  },
  {
    id: '3',
    descricao: 'Formação Continuada',
    numeroOcorrencias: 6
  }
]

export const mockPrazosEventos: PrazoEvento[] = [
  {
    id: '1',
    anoLetivoId: '1',
    descricao: 'Primeira Reunião Pedagógica',
    dataInicio: '2024-01-25',
    dataFim: '2024-01-25',
    tipoEvento: 'obrigatorio',
    eventoObrigatorioId: '1'
  },
  {
    id: '2',
    anoLetivoId: '1',
    descricao: 'Semana de Arte e Cultura',
    dataInicio: '2024-05-20',
    dataFim: '2024-05-24',
    tipoEvento: 'opcional'
  }
]

export const mockReposicoes: Reposicao[] = [
  {
    id: '1',
    calendarioId: '1',
    diaPerdido: '2024-03-15',
    diaReposto: '2024-03-23'
  },
  {
    id: '2',
    calendarioId: '1',
    diaPerdido: '2024-04-21',
    diaReposto: '2024-04-27'
  }
]
