'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Edit, Trash2, Users } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { EventoObrigatorio } from '@/types'
import { mockEventosObrigatorios } from '@/lib/mock-data'

export default function EventosObrigatoriosPage() {
  const [eventosObrigatorios, setEventosObrigatorios] = useState<EventoObrigatorio[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<EventoObrigatorio | null>(null)
  const [formData, setFormData] = useState({
    descricao: '',
    numeroOcorrencias: 1
  })
  const { toast } = useToast()

  useEffect(() => {
    setEventosObrigatorios(mockEventosObrigatorios)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação básica
    if (formData.numeroOcorrencias < 1) {
      toast({
        title: 'Erro de validação',
        description: 'O número de ocorrências deve ser maior que zero.',
        variant: 'destructive'
      })
      return
    }

    if (editingItem) {
      setEventosObrigatorios(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData }
          : item
      ))
      toast({
        title: 'Evento atualizado',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      const newItem: EventoObrigatorio = {
        id: Date.now().toString(),
        ...formData
      }
      setEventosObrigatorios(prev => [...prev, newItem])
      toast({
        title: 'Evento criado',
        description: 'O novo evento obrigatório foi adicionado com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      descricao: '',
      numeroOcorrencias: 1
    })
  }

  const handleEdit = (item: EventoObrigatorio) => {
    setEditingItem(item)
    setFormData({
      descricao: item.descricao,
      numeroOcorrencias: item.numeroOcorrencias
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setEventosObrigatorios(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Evento excluído',
      description: 'O evento obrigatório foi removido com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    resetForm()
    setIsDialogOpen(true)
  }

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Eventos Obrigatórios</h2>
                <p className="text-muted-foreground">
                  Gerencie os tipos de eventos obrigatórios do sistema
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Evento
              </Button>
            </div>

            {/* Estatísticas */}
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Total de Eventos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{eventosObrigatorios.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Tipos de eventos cadastrados
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Total de Ocorrências</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {eventosObrigatorios.reduce((sum, evento) => sum + evento.numeroOcorrencias, 0)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Ocorrências esperadas por ano
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Média por Evento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {eventosObrigatorios.length > 0 
                      ? Math.round(eventosObrigatorios.reduce((sum, evento) => sum + evento.numeroOcorrencias, 0) / eventosObrigatorios.length * 10) / 10
                      : 0
                    }
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Ocorrências por tipo
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  Lista de Eventos Obrigatórios
                </CardTitle>
                <CardDescription>
                  Visualize e gerencie todos os eventos obrigatórios cadastrados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Número de Ocorrências</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {eventosObrigatorios.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.descricao}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <span>{item.numeroOcorrencias}</span>
                            <span className="text-sm text-muted-foreground">
                              {item.numeroOcorrencias === 1 ? 'vez' : 'vezes'} por ano
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir o evento "{item.descricao}"? 
                                    Esta ação não pode ser desfeita e pode afetar prazos e eventos já cadastrados.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Evento Obrigatório' : 'Novo Evento Obrigatório'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias no evento obrigatório.'
                    : 'Preencha os dados para criar um novo evento obrigatório.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="descricao" className="text-right">
                      Descrição
                    </Label>
                    <Textarea
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                      className="col-span-3"
                      placeholder="Ex: Reunião Pedagógica, Conselho de Classe..."
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="numeroOcorrencias" className="text-right">
                      Ocorrências
                    </Label>
                    <Input
                      id="numeroOcorrencias"
                      type="number"
                      min="1"
                      value={formData.numeroOcorrencias}
                      onChange={(e) => setFormData(prev => ({ ...prev, numeroOcorrencias: parseInt(e.target.value) || 1 }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Evento'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
