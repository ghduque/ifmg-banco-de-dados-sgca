'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Plus, Edit, Trash2, Filter, AlertTriangle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { Data, CategoriaData } from '@/types'
import { mockDatas, mockCategoriasDatas } from '@/lib/mock-data'

export default function DatasPage() {
  const [datas, setDatas] = useState<Data[]>([])
  const [categoriasDatas, setCategoriasDatas] = useState<CategoriaData[]>([])
  const [filtroCategoria, setFiltroCategoria] = useState<string>('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<Data | null>(null)
  const [formData, setFormData] = useState({
    categoriaDataId: '',
    descricao: '',
    inicio: '',
    fim: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    setDatas(mockDatas)
    setCategoriasDatas(mockCategoriasDatas)
  }, [])

  const datasFiltradas = filtroCategoria && filtroCategoria !== 'todos'
    ? datas.filter(data => data.categoriaDataId === filtroCategoria)
    : datas

  const getCategoriaNome = (categoriaId: string) => {
    const categoria = categoriasDatas.find(c => c.id === categoriaId)
    return categoria ? categoria.nome : 'Não encontrado'
  }

  const getCategoriaColor = (categoriaId: string) => {
    const categoria = categoriasDatas.find(c => c.id === categoriaId)
    return categoria ? categoria.cor : '#gray'
  }

  const calcularDias = (inicio: string, fim: string) => {
    const dataInicio = new Date(inicio)
    const dataFim = new Date(fim)
    const diffTime = Math.abs(dataFim.getTime() - dataInicio.getTime())
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação de datas
    if (new Date(formData.inicio) > new Date(formData.fim)) {
      toast({
        title: 'Erro de validação',
        description: 'A data de início deve ser anterior ou igual à data de fim.',
        variant: 'destructive'
      })
      return
    }

    if (editingItem) {
      setDatas(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData }
          : item
      ))
      toast({
        title: 'Período atualizado',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      const newItem: Data = {
        id: Date.now().toString(),
        ...formData
      }
      setDatas(prev => [...prev, newItem])
      toast({
        title: 'Período criado',
        description: 'O novo período foi adicionado com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      categoriaDataId: '',
      descricao: '',
      inicio: '',
      fim: ''
    })
  }

  const handleEdit = (item: Data) => {
    setEditingItem(item)
    setFormData({
      categoriaDataId: item.categoriaDataId,
      descricao: item.descricao,
      inicio: item.inicio,
      fim: item.fim
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setDatas(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Período excluído',
      description: 'O período foi removido com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    resetForm()
    setIsDialogOpen(true)
  }

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Datas</h2>
                <p className="text-muted-foreground">
                  Gerencie os períodos de datas por categoria
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Período
              </Button>
            </div>

            {/* Filtros */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="filtro-categoria">Categoria:</Label>
                    <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
                      <SelectTrigger className="w-[250px]">
                        <SelectValue placeholder="Todas as categorias" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todas as categorias</SelectItem>
                        {categoriasDatas.map((categoria) => (
                          <SelectItem key={categoria.id} value={categoria.id}>
                            <div className="flex items-center space-x-2">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: categoria.cor }}
                              ></div>
                              <span>{categoria.nome}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {filtroCategoria && filtroCategoria !== 'todos' && (
                    <Button 
                      variant="outline" 
                      onClick={() => setFiltroCategoria('todos')}
                    >
                      Limpar Filtro
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lista de Períodos</CardTitle>
                <CardDescription>
                  Visualize e gerencie todos os períodos cadastrados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Data Início</TableHead>
                      <TableHead>Data Fim</TableHead>
                      <TableHead>Duração</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {datasFiltradas.map((item) => {
                      const categoria = categoriasDatas.find(c => c.id === item.categoriaDataId)
                      const duracao = calcularDias(item.inicio, item.fim)
                      const diasFaltantes = categoria && categoria.numeroMinimoDias > 0 
                        ? Math.max(0, categoria.numeroMinimoDias - duracao) 
                        : 0

                      return (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.descricao}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: getCategoriaColor(item.categoriaDataId) }}
                              ></div>
                              <span>{getCategoriaNome(item.categoriaDataId)}</span>
                            </div>
                          </TableCell>
                          <TableCell>{new Date(item.inicio).toLocaleDateString('pt-BR')}</TableCell>
                          <TableCell>{new Date(item.fim).toLocaleDateString('pt-BR')}</TableCell>
                          <TableCell>{duracao} dias</TableCell>
                          <TableCell>
                            {diasFaltantes > 0 ? (
                              <Badge variant="destructive" className="flex items-center w-fit">
                                <AlertTriangle className="mr-1 h-3 w-3" />
                                Faltam {diasFaltantes} dias
                              </Badge>
                            ) : (
                              <Badge variant="default">Completo</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEdit(item)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Tem certeza que deseja excluir o período "{item.descricao}"? 
                                      Esta ação não pode ser desfeita.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                      Excluir
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Período' : 'Novo Período'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias no período.'
                    : 'Preencha os dados para criar um novo período.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="categoria" className="text-right">
                      Categoria
                    </Label>
                    <Select 
                      value={formData.categoriaDataId || 'placeholder'} 
                      onValueChange={(value) => {
                        if (value !== 'placeholder') {
                          setFormData(prev => ({ ...prev, categoriaDataId: value }))
                        }
                      }}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Selecione a categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="placeholder" disabled>Selecione a categoria</SelectItem>
                        {categoriasDatas.map((categoria) => (
                          <SelectItem key={categoria.id} value={categoria.id}>
                            <div className="flex items-center space-x-2">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: categoria.cor }}
                              ></div>
                              <span>{categoria.nome}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="descricao" className="text-right">
                      Descrição
                    </Label>
                    <Input
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="inicio" className="text-right">
                      Data Início
                    </Label>
                    <Input
                      id="inicio"
                      type="date"
                      value={formData.inicio}
                      onChange={(e) => setFormData(prev => ({ ...prev, inicio: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="fim" className="text-right">
                      Data Fim
                    </Label>
                    <Input
                      id="fim"
                      type="date"
                      value={formData.fim}
                      onChange={(e) => setFormData(prev => ({ ...prev, fim: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Período'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
