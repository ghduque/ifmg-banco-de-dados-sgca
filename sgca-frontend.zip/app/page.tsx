'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Calendar, CalendarDays, Clock, GraduationCap, AlertTriangle, CheckCircle, Users, BarChart3 } from 'lucide-react'
import { useState } from 'react'

export default function Dashboard() {
  // Fix the Select component error in the dashboard by ensuring no empty string values are used
  // Update the filter state initialization
  const [filtroAnoLetivo, setFiltroAnoLetivo] = useState<string>('todos')

  // Dados mockados para o dashboard
  const stats = {
    anosLetivos: { total: 2, ativos: 1, pendentes: 1 },
    calendarios: { total: 3, sincronizados: 2, pendentes: 1 },
    categoriasDatas: { total: 8, configuradas: 6, pendentes: 2 },
    eventosObrigatorios: { total: 12, cadastrados: 8, pendentes: 4 }
  }

  const recentActivities = [
    { id: 1, action: 'Calendário 2024 sincronizado', time: '2 horas atrás', type: 'success' },
    { id: 2, action: 'Nova categoria "Provas Finais" criada', time: '4 horas atrás', type: 'info' },
    { id: 3, action: 'Reposição de aula cadastrada', time: '1 dia atrás', type: 'info' },
    { id: 4, action: 'Evento obrigatório pendente', time: '2 dias atrás', type: 'warning' }
  ]

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
              <p className="text-muted-foreground">
                Visão geral do sistema de gestão de calendário acadêmico
              </p>
            </div>

            {/* Cards de estatísticas */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Anos Letivos</CardTitle>
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.anosLetivos.total}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.anosLetivos.ativos} ativo, {stats.anosLetivos.pendentes} pendente
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Calendários</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.calendarios.total}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.calendarios.sincronizados} sincronizados
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Categorias</CardTitle>
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.categoriasDatas.total}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.categoriasDatas.configuradas} configuradas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Eventos</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.eventosObrigatorios.total}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.eventosObrigatorios.cadastrados} cadastrados
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              {/* Progresso do ano letivo */}
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Progresso do Ano Letivo 2024</CardTitle>
                  <CardDescription>
                    Acompanhamento das atividades do ano letivo atual
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Dias letivos cumpridos</span>
                      <span className="text-sm text-muted-foreground">180/200 dias</span>
                    </div>
                    <Progress value={90} className="w-full" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Eventos obrigatórios</span>
                      <span className="text-sm text-muted-foreground">8/12 realizados</span>
                    </div>
                    <Progress value={67} className="w-full" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Calendários sincronizados</span>
                      <span className="text-sm text-muted-foreground">2/3 calendários</span>
                    </div>
                    <Progress value={67} className="w-full" />
                  </div>
                </CardContent>
              </Card>

              {/* Atividades recentes */}
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Atividades Recentes</CardTitle>
                  <CardDescription>
                    Últimas ações realizadas no sistema
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivities.map((activity) => (
                      <div key={activity.id} className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          {activity.type === 'success' && (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          )}
                          {activity.type === 'warning' && (
                            <AlertTriangle className="h-4 w-4 text-yellow-500" />
                          )}
                          {activity.type === 'info' && (
                            <Clock className="h-4 w-4 text-blue-500" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {activity.action}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {activity.time}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Alertas e pendências */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                  Pendências e Alertas
                </CardTitle>
                <CardDescription>
                  Itens que requerem atenção
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4 eventos obrigatórios ainda não foram cadastrados para 2024</span>
                    </div>
                    <Badge variant="outline">Pendente</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Calendar className="h-4 w-4 text-blue-500" />
                      <span className="text-sm">Calendário 2025 precisa ser sincronizado</span>
                    </div>
                    <Badge variant="outline">Ação Necessária</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <BarChart3 className="h-4 w-4 text-red-500" />
                      <span className="text-sm">Categoria "Aulas" está 5 dias abaixo do mínimo exigido</span>
                    </div>
                    <Badge variant="destructive">Crítico</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
