'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Plus, Edit, Trash2, Filter, BarChart3, Calendar } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { Reposicao, Calendario, DiasLetivos } from '@/types'
import { mockReposicoes, mockCalendarios } from '@/lib/mock-data'

export default function EqualizacaoPage() {
  const [reposicoes, setReposicoes] = useState<Reposicao[]>([])
  const [calendarios, setCalendarios] = useState<Calendario[]>([])
  const [calendarioSelecionado, setCalendarioSelecionado] = useState<string>('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<Reposicao | null>(null)
  const [formData, setFormData] = useState({
    calendarioId: '',
    diaPerdido: '',
    diaReposto: ''
  })
  const { toast } = useToast()

  // Dados mockados para dias letivos
  const [diasLetivos] = useState<DiasLetivos>({
    segunda: 42,
    terca: 41,
    quarta: 43,
    quinta: 40,
    sexta: 44
  })

  useEffect(() => {
    setReposicoes(mockReposicoes)
    setCalendarios(mockCalendarios.filter(c => c.sincronizado)) // Apenas calendários sincronizados
  }, [])

  const reposicoesFiltradas = calendarioSelecionado && calendarioSelecionado !== 'todos'
    ? reposicoes.filter(rep => rep.calendarioId === calendarioSelecionado)
    : reposicoes

  const getCalendarioNome = (calendarioId: string) => {
    const calendario = calendarios.find(c => c.id === calendarioId)
    return calendario ? calendario.nome : 'Não encontrado'
  }

  const getDiaSemana = (data: string) => {
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado']
    const date = new Date(data)
    return diasSemana[date.getDay()]
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação básica
    if (new Date(formData.diaPerdido) >= new Date(formData.diaReposto)) {
      toast({
        title: 'Erro de validação',
        description: 'O dia reposto deve ser posterior ao dia perdido.',
        variant: 'destructive'
      })
      return
    }

    if (editingItem) {
      setReposicoes(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData }
          : item
      ))
      toast({
        title: 'Reposição atualizada',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      const newItem: Reposicao = {
        id: Date.now().toString(),
        ...formData
      }
      setReposicoes(prev => [...prev, newItem])
      toast({
        title: 'Reposição criada',
        description: 'A nova reposição foi adicionada com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      calendarioId: '',
      diaPerdido: '',
      diaReposto: ''
    })
  }

  const handleEdit = (item: Reposicao) => {
    setEditingItem(item)
    setFormData({
      calendarioId: item.calendarioId,
      diaPerdido: item.diaPerdido,
      diaReposto: item.diaReposto
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setReposicoes(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Reposição excluída',
      description: 'A reposição foi removida com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    resetForm()
    setIsDialogOpen(true)
  }

  const calcularEqualizacao = () => {
    const valores = Object.values(diasLetivos)
    const maximo = Math.max(...valores)
    const minimo = Math.min(...valores)
    return { maximo, minimo, diferenca: maximo - minimo }
  }

  const equalizacao = calcularEqualizacao()

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Equalização</h2>
                <p className="text-muted-foreground">
                  Gerencie a equalização de dias letivos e reposições
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Reposição
              </Button>
            </div>

            {/* Gráfico de Dias Letivos */}
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="mr-2 h-5 w-5" />
                    Dias Letivos por Dia da Semana
                  </CardTitle>
                  <CardDescription>
                    Distribuição atual de dias letivos (Segunda a Sexta)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(diasLetivos).map(([dia, quantidade]) => (
                    <div key={dia} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">{dia}-feira</span>
                        <span className="text-sm text-muted-foreground">{quantidade} dias</span>
                      </div>
                      <Progress 
                        value={(quantidade / equalizacao.maximo) * 100} 
                        className="w-full" 
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas de Equalização</CardTitle>
                  <CardDescription>
                    Resumo da distribuição de dias letivos
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{equalizacao.minimo}</div>
                      <div className="text-sm text-muted-foreground">Mínimo</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{equalizacao.maximo}</div>
                      <div className="text-sm text-muted-foreground">Máximo</div>
                    </div>
                  </div>
                  <div className="text-center pt-4 border-t">
                    <div className="text-2xl font-bold text-orange-600">{equalizacao.diferenca}</div>
                    <div className="text-sm text-muted-foreground">Diferença</div>
                  </div>
                  <div className="pt-2">
                    <Badge variant={equalizacao.diferenca <= 2 ? "default" : "destructive"}>
                      {equalizacao.diferenca <= 2 ? "Bem Equalizado" : "Precisa Equalizar"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Filtros */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="filtro-calendario">Calendário:</Label>
                    <Select value={calendarioSelecionado} onValueChange={setCalendarioSelecionado}>
                      <SelectTrigger className="w-[250px]">
                        <SelectValue placeholder="Todos os calendários" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos os calendários</SelectItem>
                        {calendarios.map((calendario) => (
                          <SelectItem key={calendario.id} value={calendario.id}>
                            {calendario.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {calendarioSelecionado && calendarioSelecionado !== 'todos' && (
                    <Button 
                      variant="outline" 
                      onClick={() => setCalendarioSelecionado('todos')}
                    >
                      Limpar Filtro
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lista de Reposições</CardTitle>
                <CardDescription>
                  Visualize e gerencie todas as reposições cadastradas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Calendário</TableHead>
                      <TableHead>Dia Perdido</TableHead>
                      <TableHead>Dia da Semana</TableHead>
                      <TableHead>Dia Reposto</TableHead>
                      <TableHead>Dia da Semana</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {reposicoesFiltradas.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{getCalendarioNome(item.calendarioId)}</TableCell>
                        <TableCell>{new Date(item.diaPerdido).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{getDiaSemana(item.diaPerdido)}</Badge>
                        </TableCell>
                        <TableCell>{new Date(item.diaReposto).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{getDiaSemana(item.diaReposto)}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir esta reposição? 
                                    Esta ação não pode ser desfeita.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Reposição' : 'Nova Reposição'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias na reposição.'
                    : 'Preencha os dados para criar uma nova reposição.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="calendario" className="text-right">
                      Calendário
                    </Label>
                    <Select 
                      value={formData.calendarioId || 'placeholder'} 
                      onValueChange={(value) => {
                        if (value !== 'placeholder') {
                          setFormData(prev => ({ ...prev, calendarioId: value }))
                        }
                      }}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Selecione o calendário" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="placeholder" disabled>Selecione o calendário</SelectItem>
                        {calendarios.map((calendario) => (
                          <SelectItem key={calendario.id} value={calendario.id}>
                            {calendario.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="diaPerdido" className="text-right">
                      Dia Perdido
                    </Label>
                    <div className="col-span-3 space-y-2">
                      <Input
                        id="diaPerdido"
                        type="date"
                        value={formData.diaPerdido}
                        onChange={(e) => setFormData(prev => ({ ...prev, diaPerdido: e.target.value }))}
                        required
                      />
                      {formData.diaPerdido && (
                        <div className="text-sm text-muted-foreground">
                          {getDiaSemana(formData.diaPerdido)}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="diaReposto" className="text-right">
                      Dia Reposto
                    </Label>
                    <div className="col-span-3 space-y-2">
                      <Input
                        id="diaReposto"
                        type="date"
                        value={formData.diaReposto}
                        onChange={(e) => setFormData(prev => ({ ...prev, diaReposto: e.target.value }))}
                        required
                      />
                      {formData.diaReposto && (
                        <div className="text-sm text-muted-foreground">
                          {getDiaSemana(formData.diaReposto)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Reposição'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
