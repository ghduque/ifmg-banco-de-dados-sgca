'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Plus, Edit, Trash2, Filter, Clock, AlertTriangle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { PrazoEvento, AnoLetivo, EventoObrigatorio } from '@/types'
import { mockPrazosEventos, mockAnosLetivos, mockEventosObrigatorios } from '@/lib/mock-data'

export default function PrazosEventosPage() {
  const [prazosEventos, setPrazosEventos] = useState<PrazoEvento[]>([])
  const [anosLetivos, setAnosLetivos] = useState<AnoLetivo[]>([])
  const [eventosObrigatorios, setEventosObrigatorios] = useState<EventoObrigatorio[]>([])
  const [filtroAnoLetivo, setFiltroAnoLetivo] = useState<string>('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<PrazoEvento | null>(null)
  const [formData, setFormData] = useState({
    anoLetivoId: '',
    descricao: '',
    dataInicio: '',
    dataFim: '',
    tipoEvento: 'opcional' as 'obrigatorio' | 'opcional',
    eventoObrigatorioId: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    setPrazosEventos(mockPrazosEventos)
    setAnosLetivos(mockAnosLetivos)
    setEventosObrigatorios(mockEventosObrigatorios)
  }, [])

  const eventosFiltrados = filtroAnoLetivo && filtroAnoLetivo !== 'todos'
    ? prazosEventos.filter(evento => evento.anoLetivoId === filtroAnoLetivo)
    : prazosEventos

  const getAnoLetivoNome = (anoLetivoId: string) => {
    const ano = anosLetivos.find(a => a.id === anoLetivoId)
    return ano ? `${ano.ano} - ${ano.descricao}` : 'Não encontrado'
  }

  const getEventoObrigatorioNome = (eventoId: string) => {
    const evento = eventosObrigatorios.find(e => e.id === eventoId)
    return evento ? evento.descricao : 'Não encontrado'
  }

  const getEventosPendentes = () => {
    // Simular eventos obrigatórios pendentes
    return eventosObrigatorios.filter(evento => {
      const ocorrenciasCadastradas = prazosEventos.filter(p => 
        p.tipoEvento === 'obrigatorio' && p.eventoObrigatorioId === evento.id
      ).length
      return ocorrenciasCadastradas < evento.numeroOcorrencias
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação de datas
    if (new Date(formData.dataInicio) > new Date(formData.dataFim)) {
      toast({
        title: 'Erro de validação',
        description: 'A data de início deve ser anterior ou igual à data de fim.',
        variant: 'destructive'
      })
      return
    }

    // Validação para eventos obrigatórios
    if (formData.tipoEvento === 'obrigatorio' && !formData.eventoObrigatorioId) {
      toast({
        title: 'Erro de validação',
        description: 'Selecione um evento obrigatório.',
        variant: 'destructive'
      })
      return
    }

    if (editingItem) {
      setPrazosEventos(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData }
          : item
      ))
      toast({
        title: 'Prazo/Evento atualizado',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      const newItem: PrazoEvento = {
        id: Date.now().toString(),
        ...formData,
        eventoObrigatorioId: formData.tipoEvento === 'obrigatorio' ? formData.eventoObrigatorioId : undefined
      }
      setPrazosEventos(prev => [...prev, newItem])
      toast({
        title: 'Prazo/Evento criado',
        description: 'O novo prazo/evento foi adicionado com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      anoLetivoId: '',
      descricao: '',
      dataInicio: '',
      dataFim: '',
      tipoEvento: 'opcional',
      eventoObrigatorioId: ''
    })
  }

  const handleEdit = (item: PrazoEvento) => {
    setEditingItem(item)
    setFormData({
      anoLetivoId: item.anoLetivoId,
      descricao: item.descricao,
      dataInicio: item.dataInicio,
      dataFim: item.dataFim,
      tipoEvento: item.tipoEvento,
      eventoObrigatorioId: item.eventoObrigatorioId || ''
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setPrazosEventos(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Prazo/Evento excluído',
      description: 'O prazo/evento foi removido com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    resetForm()
    setIsDialogOpen(true)
  }

  const eventosPendentes = getEventosPendentes()

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Prazos e Eventos</h2>
                <p className="text-muted-foreground">
                  Gerencie prazos e eventos por ano letivo
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Prazo/Evento
              </Button>
            </div>

            {/* Eventos Pendentes */}
            {eventosPendentes.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-orange-600">
                    <AlertTriangle className="mr-2 h-5 w-5" />
                    Eventos Obrigatórios Pendentes
                  </CardTitle>
                  <CardDescription>
                    Os seguintes eventos obrigatórios ainda não foram totalmente cadastrados
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {eventosPendentes.map((evento) => {
                      const ocorrenciasCadastradas = prazosEventos.filter(p => 
                        p.tipoEvento === 'obrigatorio' && p.eventoObrigatorioId === evento.id
                      ).length
                      const faltam = evento.numeroOcorrencias - ocorrenciasCadastradas

                      return (
                        <div key={evento.id} className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                          <div>
                            <span className="font-medium">{evento.descricao}</span>
                            <span className="text-sm text-muted-foreground ml-2">
                              ({ocorrenciasCadastradas}/{evento.numeroOcorrencias} cadastradas)
                            </span>
                          </div>
                          <Badge variant="outline">
                            Faltam {faltam}
                          </Badge>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Filtros */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="filtro-ano">Ano Letivo:</Label>
                    <Select value={filtroAnoLetivo} onValueChange={setFiltroAnoLetivo}>
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Todos os anos" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos os anos</SelectItem>
                        {anosLetivos.map((ano) => (
                          <SelectItem key={ano.id} value={ano.id}>
                            {ano.ano} - {ano.descricao}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {filtroAnoLetivo && filtroAnoLetivo !== 'todos' && (
                    <Button 
                      variant="outline" 
                      onClick={() => setFiltroAnoLetivo('todos')}
                    >
                      Limpar Filtro
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="mr-2 h-5 w-5" />
                  Lista de Prazos e Eventos
                </CardTitle>
                <CardDescription>
                  Visualize e gerencie todos os prazos e eventos cadastrados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Ano Letivo</TableHead>
                      <TableHead>Data Início</TableHead>
                      <TableHead>Data Fim</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Evento Obrigatório</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {eventosFiltrados.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.descricao}</TableCell>
                        <TableCell>{getAnoLetivoNome(item.anoLetivoId)}</TableCell>
                        <TableCell>{new Date(item.dataInicio).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>{new Date(item.dataFim).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>
                          <Badge variant={item.tipoEvento === 'obrigatorio' ? "default" : "secondary"}>
                            {item.tipoEvento === 'obrigatorio' ? 'Obrigatório' : 'Opcional'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {item.eventoObrigatorioId ? getEventoObrigatorioNome(item.eventoObrigatorioId) : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir o prazo/evento "{item.descricao}"? 
                                    Esta ação não pode ser desfeita.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Prazo/Evento' : 'Novo Prazo/Evento'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias no prazo/evento.'
                    : 'Preencha os dados para criar um novo prazo/evento.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="anoLetivo" className="text-right">
                      Ano Letivo
                    </Label>
                    <Select 
                      value={formData.anoLetivoId || 'placeholder'} 
                      onValueChange={(value) => {
                        if (value !== 'placeholder') {
                          setFormData(prev => ({ ...prev, anoLetivoId: value }))
                        }
                      }}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Selecione o ano letivo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="placeholder" disabled>Selecione o ano letivo</SelectItem>
                        {anosLetivos.map((ano) => (
                          <SelectItem key={ano.id} value={ano.id}>
                            {ano.ano} - {ano.descricao}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="descricao" className="text-right">
                      Descrição
                    </Label>
                    <Textarea
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dataInicio" className="text-right">
                      Data Início
                    </Label>
                    <Input
                      id="dataInicio"
                      type="date"
                      value={formData.dataInicio}
                      onChange={(e) => setFormData(prev => ({ ...prev, dataInicio: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dataFim" className="text-right">
                      Data Fim
                    </Label>
                    <Input
                      id="dataFim"
                      type="date"
                      value={formData.dataFim}
                      onChange={(e) => setFormData(prev => ({ ...prev, dataFim: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label className="text-right">
                      Tipo de Evento
                    </Label>
                    <RadioGroup
                      value={formData.tipoEvento}
                      onValueChange={(value: 'obrigatorio' | 'opcional') => 
                        setFormData(prev => ({ ...prev, tipoEvento: value, eventoObrigatorioId: value === 'opcional' ? '' : prev.eventoObrigatorioId }))
                      }
                      className="col-span-3"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="opcional" id="opcional" />
                        <Label htmlFor="opcional">Opcional</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="obrigatorio" id="obrigatorio" />
                        <Label htmlFor="obrigatorio">Obrigatório</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {formData.tipoEvento === 'obrigatorio' && (
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="eventoObrigatorio" className="text-right">
                        Evento Obrigatório
                      </Label>
                      <Select 
                        value={formData.eventoObrigatorioId || 'placeholder'} 
                        onValueChange={(value) => {
                          if (value !== 'placeholder') {
                            setFormData(prev => ({ ...prev, eventoObrigatorioId: value }))
                          }
                        }}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Selecione o evento obrigatório" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="placeholder" disabled>Selecione o evento obrigatório</SelectItem>
                          {eventosObrigatorios.map((evento) => (
                            <SelectItem key={evento.id} value={evento.id}>
                              {evento.descricao}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Prazo/Evento'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
