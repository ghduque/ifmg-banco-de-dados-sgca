'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Calendar, Download, Filter, Eye } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { AnoLetivo, Calendario, CategoriaData, Data } from '@/types'
import { mockAnosLetivos, mockCalendarios, mockCategoriasDatas, mockDatas } from '@/lib/mock-data'

export default function VisualizacaoPage() {
  const [anosLetivos, setAnosLetivos] = useState<AnoLetivo[]>([])
  const [calendarios, setCalendarios] = useState<Calendario[]>([])
  const [categoriasDatas, setCategoriasDatas] = useState<CategoriaData[]>([])
  const [datas, setDatas] = useState<Data[]>([])
  const [anoSelecionado, setAnoSelecionado] = useState<string>('')
  const [calendarioSelecionado, setCalendarioSelecionado] = useState<string>('')
  const [mesAtual, setMesAtual] = useState(new Date().getMonth())
  const [anoAtual, setAnoAtual] = useState(new Date().getFullYear())
  const { toast } = useToast()

  useEffect(() => {
    setAnosLetivos(mockAnosLetivos)
    setCalendarios(mockCalendarios)
    setCategoriasDatas(mockCategoriasDatas)
    setDatas(mockDatas)
  }, [])

  const calendariosFiltrados = anoSelecionado 
    ? calendarios.filter(cal => cal.anoLetivoId === anoSelecionado)
    : []

  const getAnoLetivoNome = (anoLetivoId: string) => {
    const ano = anosLetivos.find(a => a.id === anoLetivoId)
    return ano ? `${ano.ano} - ${ano.descricao}` : 'Não encontrado'
  }

  const getCalendarioNome = (calendarioId: string) => {
    const calendario = calendarios.find(c => c.id === calendarioId)
    return calendario ? calendario.nome : 'Não encontrado'
  }

  const handleExportCalendar = () => {
    if (!calendarioSelecionado) {
      toast({
        title: 'Erro',
        description: 'Selecione um calendário para exportar.',
        variant: 'destructive'
      })
      return
    }

    toast({
      title: 'Exportação iniciada',
      description: 'O calendário está sendo preparado para download.'
    })
  }

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay()
  }

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(mesAtual, anoAtual)
    const firstDay = getFirstDayOfMonth(mesAtual, anoAtual)
    const days = []

    // Dias vazios no início
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-24 border border-gray-200 dark:border-gray-700"></div>)
    }

    // Dias do mês
    for (let day = 1; day <= daysInMonth; day++) {
      const currentDate = new Date(anoAtual, mesAtual, day)
      const dateString = currentDate.toISOString().split('T')[0]
      
      // Buscar eventos para este dia
      const eventosNoDia = datas.filter(data => {
        const inicio = new Date(data.inicio)
        const fim = new Date(data.fim)
        return currentDate >= inicio && currentDate <= fim
      })

      days.push(
        <div key={day} className="h-24 border border-gray-200 dark:border-gray-700 p-1 overflow-hidden">
          <div className="font-semibold text-sm mb-1">{day}</div>
          <div className="space-y-1">
            {eventosNoDia.slice(0, 2).map((evento, index) => {
              const categoria = categoriasDatas.find(c => c.id === evento.categoriaDataId)
              return (
                <div
                  key={index}
                  className="text-xs p-1 rounded truncate"
                  style={{ 
                    backgroundColor: categoria?.cor + '20',
                    borderLeft: `3px solid ${categoria?.cor}`
                  }}
                  title={evento.descricao}
                >
                  {evento.descricao}
                </div>
              )
            })}
            {eventosNoDia.length > 2 && (
              <div className="text-xs text-muted-foreground">
                +{eventosNoDia.length - 2} mais
              </div>
            )}
          </div>
        </div>
      )
    }

    return days
  }

  const meses = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ]

  const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Visualização do Calendário</h2>
                <p className="text-muted-foreground">
                  Visualize e exporte calendários acadêmicos
                </p>
              </div>
              <Button onClick={handleExportCalendar} disabled={!calendarioSelecionado}>
                <Download className="mr-2 h-4 w-4" />
                Exportar Calendário
              </Button>
            </div>

            {/* Filtros */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Seleção de Calendário
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Ano Letivo</label>
                    <Select value={anoSelecionado || 'placeholder'} onValueChange={(value) => {
                      if (value !== 'placeholder') {
                        setAnoSelecionado(value)
                        setCalendarioSelecionado('') // Reset calendar selection when year changes
                      }
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o ano letivo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="placeholder" disabled>Selecione o ano letivo</SelectItem>
                        {anosLetivos.map((ano) => (
                          <SelectItem key={ano.id} value={ano.id}>
                            {ano.ano} - {ano.descricao}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Calendário</label>
                    <Select 
                      value={calendarioSelecionado || 'placeholder'} 
                      onValueChange={(value) => {
                        if (value !== 'placeholder') {
                          setCalendarioSelecionado(value)
                        }
                      }}
                      disabled={!anoSelecionado}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o calendário" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="placeholder" disabled>Selecione o calendário</SelectItem>
                        {calendariosFiltrados.map((calendario) => (
                          <SelectItem key={calendario.id} value={calendario.id}>
                            {calendario.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Mês/Ano</label>
                    <div className="flex space-x-2">
                      <Select 
                        value={mesAtual.toString()} 
                        onValueChange={(value) => setMesAtual(parseInt(value))}
                      >
                        <SelectTrigger className="flex-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {meses.map((mes, index) => (
                            <SelectItem key={index} value={index.toString()}>
                              {mes}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select 
                        value={anoAtual.toString()} 
                        onValueChange={(value) => setAnoAtual(parseInt(value))}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[2023, 2024, 2025, 2026].map((ano) => (
                            <SelectItem key={ano} value={ano.toString()}>
                              {ano}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Legenda das categorias */}
            {calendarioSelecionado && (
              <Card>
                <CardHeader>
                  <CardTitle>Legenda</CardTitle>
                  <CardDescription>
                    Categorias de datas para o calendário selecionado
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3">
                    {categoriasDatas
                      .filter(cat => {
                        const calendario = calendarios.find(c => c.id === calendarioSelecionado)
                        return calendario && cat.calendarioId === calendario.id
                      })
                      .map((categoria) => (
                        <Badge 
                          key={categoria.id} 
                          variant="outline"
                          className="flex items-center space-x-2"
                        >
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: categoria.cor }}
                          ></div>
                          <span>{categoria.nome}</span>
                        </Badge>
                      ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Calendário Visual */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar className="mr-2 h-5 w-5" />
                    {meses[mesAtual]} {anoAtual}
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (mesAtual === 0) {
                          setMesAtual(11)
                          setAnoAtual(anoAtual - 1)
                        } else {
                          setMesAtual(mesAtual - 1)
                        }
                      }}
                    >
                      ←
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (mesAtual === 11) {
                          setMesAtual(0)
                          setAnoAtual(anoAtual + 1)
                        } else {
                          setMesAtual(mesAtual + 1)
                        }
                      }}
                    >
                      →
                    </Button>
                  </div>
                </CardTitle>
                {calendarioSelecionado && (
                  <CardDescription>
                    Visualizando: {getCalendarioNome(calendarioSelecionado)} - {getAnoLetivoNome(anoSelecionado)}
                  </CardDescription>
                )}
              </CardHeader>
              <CardContent>
                {calendarioSelecionado ? (
                  <div className="grid grid-cols-7 gap-0 border border-gray-200 dark:border-gray-700">
                    {/* Cabeçalho dos dias da semana */}
                    {diasSemana.map((dia) => (
                      <div key={dia} className="h-10 border border-gray-200 dark:border-gray-700 flex items-center justify-center font-semibold bg-muted">
                        {dia}
                      </div>
                    ))}
                    {/* Dias do calendário */}
                    {renderCalendar()}
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64 text-muted-foreground">
                    <div className="text-center">
                      <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Selecione um ano letivo e calendário para visualizar</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Resumo estatístico */}
            {calendarioSelecionado && (
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Total de Categorias</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {categoriasDatas.filter(cat => {
                        const calendario = calendarios.find(c => c.id === calendarioSelecionado)
                        return calendario && cat.calendarioId === calendario.id
                      }).length}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Períodos Cadastrados</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {datas.filter(data => {
                        const categoria = categoriasDatas.find(c => c.id === data.categoriaDataId)
                        const calendario = calendarios.find(c => c.id === calendarioSelecionado)
                        return categoria && calendario && categoria.calendarioId === calendario.id
                      }).length}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Status do Calendário</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {calendarios.find(c => c.id === calendarioSelecionado)?.sincronizado ? (
                        <Badge variant="default">Sincronizado</Badge>
                      ) : (
                        <Badge variant="secondary">Não Sincronizado</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}
