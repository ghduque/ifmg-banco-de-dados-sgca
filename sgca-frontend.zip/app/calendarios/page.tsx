'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Plus, Edit, Trash2, AlertTriangle, CheckCircle, Filter } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { Calendario, AnoLetivo } from '@/types'
import { mockCalendarios, mockAnosLetivos } from '@/lib/mock-data'

export default function CalendariosPage() {
  const [calendarios, setCalendarios] = useState<Calendario[]>([])
  const [anosLetivos, setAnosLetivos] = useState<AnoLetivo[]>([])
  const [filtroAnoLetivo, setFiltroAnoLetivo] = useState<string>('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<Calendario | null>(null)
  const [formData, setFormData] = useState({
    anoLetivoId: '',
    nome: '',
    sincronizado: false
  })
  const { toast } = useToast()

  useEffect(() => {
    setCalendarios(mockCalendarios)
    setAnosLetivos(mockAnosLetivos)
  }, [])

  const calendariosFiltrados = filtroAnoLetivo && filtroAnoLetivo !== 'todos'
    ? calendarios.filter(cal => cal.anoLetivoId === filtroAnoLetivo)
    : calendarios

  const getAnoLetivoNome = (anoLetivoId: string) => {
    const ano = anosLetivos.find(a => a.id === anoLetivoId)
    return ano ? `${ano.ano} - ${ano.descricao}` : 'Não encontrado'
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingItem) {
      setCalendarios(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData }
          : item
      ))
      toast({
        title: 'Calendário atualizado',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      const newItem: Calendario = {
        id: Date.now().toString(),
        anoLetivoId: formData.anoLetivoId,
        nome: formData.nome,
        sincronizado: formData.sincronizado,
        pendencias: formData.sincronizado ? [] : ['Calendário não sincronizado']
      }
      setCalendarios(prev => [...prev, newItem])
      toast({
        title: 'Calendário criado',
        description: 'O novo calendário foi adicionado com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    setFormData({ anoLetivoId: '', nome: '', sincronizado: false })
  }

  const handleEdit = (item: Calendario) => {
    setEditingItem(item)
    setFormData({
      anoLetivoId: item.anoLetivoId,
      nome: item.nome,
      sincronizado: item.sincronizado
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setCalendarios(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Calendário excluído',
      description: 'O calendário foi removido com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    setFormData({ anoLetivoId: '', nome: '', sincronizado: false })
    setIsDialogOpen(true)
  }

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Calendários</h2>
                <p className="text-muted-foreground">
                  Gerencie os calendários por ano letivo
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Calendário
              </Button>
            </div>

            {/* Filtros */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="filtro-ano">Ano Letivo:</Label>
                    <Select value={filtroAnoLetivo} onValueChange={setFiltroAnoLetivo}>
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Todos os anos" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos os anos</SelectItem>
                        {anosLetivos.map((ano) => (
                          <SelectItem key={ano.id} value={ano.id}>
                            {ano.ano} - {ano.descricao}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {filtroAnoLetivo && filtroAnoLetivo !== 'todos' && (
                    <Button 
                      variant="outline" 
                      onClick={() => setFiltroAnoLetivo('todos')}
                    >
                      Limpar Filtro
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lista de Calendários</CardTitle>
                <CardDescription>
                  Visualize e gerencie todos os calendários cadastrados
                  {filtroAnoLetivo && ` para o ano selecionado`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Ano Letivo</TableHead>
                      <TableHead>Sincronizado</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {calendariosFiltrados.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.nome}</TableCell>
                        <TableCell>{getAnoLetivoNome(item.anoLetivoId)}</TableCell>
                        <TableCell>
                          {item.sincronizado ? (
                            <Badge variant="default" className="flex items-center w-fit">
                              <CheckCircle className="mr-1 h-3 w-3" />
                              Sim
                            </Badge>
                          ) : (
                            <Badge variant="secondary">Não</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {item.pendencias && item.pendencias.length > 0 ? (
                            <Badge variant="destructive" className="flex items-center w-fit">
                              <AlertTriangle className="mr-1 h-3 w-3" />
                              Pendências
                            </Badge>
                          ) : (
                            <Badge variant="default">Ativo</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir o calendário "{item.nome}"? 
                                    Esta ação não pode ser desfeita.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Calendário' : 'Novo Calendário'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias no calendário.'
                    : 'Preencha os dados para criar um novo calendário.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="anoLetivo" className="text-right">
                      Ano Letivo
                    </Label>
                    <Select 
                      value={formData.anoLetivoId} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, anoLetivoId: value }))}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Selecione o ano letivo" />
                      </SelectTrigger>
                      <SelectContent>
                        {anosLetivos.map((ano) => (
                          <SelectItem key={ano.id} value={ano.id}>
                            {ano.ano} - {ano.descricao}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="nome" className="text-right">
                      Nome
                    </Label>
                    <Input
                      id="nome"
                      value={formData.nome}
                      onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="sincronizado" className="text-right">
                      Sincronizado
                    </Label>
                    <div className="col-span-3 flex items-center space-x-2">
                      <Checkbox
                        id="sincronizado"
                        checked={formData.sincronizado}
                        onCheckedChange={(checked) => 
                          setFormData(prev => ({ ...prev, sincronizado: checked as boolean }))
                        }
                      />
                      <Label htmlFor="sincronizado" className="text-sm">
                        Marcar como sincronizado
                      </Label>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Calendário'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
