'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Plus, Edit, Trash2, Filter, Palette } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { CategoriaData, Calendario } from '@/types'
import { mockCategoriasDatas, mockCalendarios } from '@/lib/mock-data'

export default function CategoriasDatasPage() {
  const [categoriasDatas, setCategoriasDatas] = useState<CategoriaData[]>([])
  const [calendarios, setCalendarios] = useState<Calendario[]>([])
  const [filtroCalendario, setFiltroCalendario] = useState<string>('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<CategoriaData | null>(null)
  const [formData, setFormData] = useState({
    calendarioId: '',
    nome: '',
    cor: '#3b82f6',
    numeroMinimoDias: 0,
    datasLetivas: true,
    diasSemanaValidos: [false, true, true, true, true, true, false] // Dom-Sáb
  })
  const { toast } = useToast()

  useEffect(() => {
    setCategoriasDatas(mockCategoriasDatas)
    setCalendarios(mockCalendarios)
  }, [])

  const categoriasFiltradas = filtroCalendario && filtroCalendario !== 'todos'
    ? categoriasDatas.filter(cat => cat.calendarioId === filtroCalendario)
    : categoriasDatas

  const getCalendarioNome = (calendarioId: string) => {
    const calendario = calendarios.find(c => c.id === calendarioId)
    return calendario ? calendario.nome : 'Não encontrado'
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validar cor única por calendário
    const coresExistentes = categoriasDatas
      .filter(cat => cat.calendarioId === formData.calendarioId && cat.id !== editingItem?.id)
      .map(cat => cat.cor)
    
    if (coresExistentes.includes(formData.cor)) {
      toast({
        title: 'Erro de validação',
        description: 'Esta cor já está sendo usada neste calendário.',
        variant: 'destructive'
      })
      return
    }

    if (editingItem) {
      setCategoriasDatas(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData }
          : item
      ))
      toast({
        title: 'Categoria atualizada',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      const newItem: CategoriaData = {
        id: Date.now().toString(),
        ...formData
      }
      setCategoriasDatas(prev => [...prev, newItem])
      toast({
        title: 'Categoria criada',
        description: 'A nova categoria foi adicionada com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      calendarioId: '',
      nome: '',
      cor: '#3b82f6',
      numeroMinimoDias: 0,
      datasLetivas: true,
      diasSemanaValidos: [false, true, true, true, true, true, false]
    })
  }

  const handleEdit = (item: CategoriaData) => {
    setEditingItem(item)
    setFormData({
      calendarioId: item.calendarioId,
      nome: item.nome,
      cor: item.cor,
      numeroMinimoDias: item.numeroMinimoDias,
      datasLetivas: item.datasLetivas,
      diasSemanaValidos: item.diasSemanaValidos
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setCategoriasDatas(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Categoria excluída',
      description: 'A categoria foi removida com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    resetForm()
    setIsDialogOpen(true)
  }

  const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Categorias de Datas</h2>
                <p className="text-muted-foreground">
                  Gerencie as categorias de datas por calendário
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Categoria
              </Button>
            </div>

            {/* Filtros */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="filtro-calendario">Calendário:</Label>
                    <Select value={filtroCalendario} onValueChange={setFiltroCalendario}>
                      <SelectTrigger className="w-[250px]">
                        <SelectValue placeholder="Todos os calendários" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos os calendários</SelectItem>
                        {calendarios.map((calendario) => (
                          <SelectItem key={calendario.id} value={calendario.id}>
                            {calendario.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {filtroCalendario && filtroCalendario !== 'todos' && (
                    <Button 
                      variant="outline" 
                      onClick={() => setFiltroCalendario('todos')}
                    >
                      Limpar Filtro
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lista de Categorias de Datas</CardTitle>
                <CardDescription>
                  Visualize e gerencie todas as categorias cadastradas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Calendário</TableHead>
                      <TableHead>Cor</TableHead>
                      <TableHead>Dias Mínimos</TableHead>
                      <TableHead>Datas Letivas</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoriasFiltradas.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.nome}</TableCell>
                        <TableCell>{getCalendarioNome(item.calendarioId)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div 
                              className="w-4 h-4 rounded-full border" 
                              style={{ backgroundColor: item.cor }}
                            ></div>
                            <span className="text-sm">{item.cor}</span>
                          </div>
                        </TableCell>
                        <TableCell>{item.numeroMinimoDias}</TableCell>
                        <TableCell>
                          <Badge variant={item.datasLetivas ? "default" : "secondary"}>
                            {item.datasLetivas ? "Sim" : "Não"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir a categoria "{item.nome}"? 
                                    Esta ação não pode ser desfeita.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Categoria' : 'Nova Categoria'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias na categoria.'
                    : 'Preencha os dados para criar uma nova categoria.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="calendario" className="text-right">
                      Calendário
                    </Label>
                    <Select 
                      value={formData.calendarioId || 'placeholder'} 
                      onValueChange={(value) => {
                        if (value !== 'placeholder') {
                          setFormData(prev => ({ ...prev, calendarioId: value }))
                        }
                      }}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Selecione o calendário" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="placeholder" disabled>Selecione o calendário</SelectItem>
                        {calendarios.map((calendario) => (
                          <SelectItem key={calendario.id} value={calendario.id}>
                            {calendario.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="nome" className="text-right">
                      Nome
                    </Label>
                    <Input
                      id="nome"
                      value={formData.nome}
                      onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="cor" className="text-right">
                      Cor
                    </Label>
                    <div className="col-span-3 flex items-center space-x-2">
                      <Input
                        id="cor"
                        type="color"
                        value={formData.cor}
                        onChange={(e) => setFormData(prev => ({ ...prev, cor: e.target.value }))}
                        className="w-16 h-10"
                      />
                      <Input
                        value={formData.cor}
                        onChange={(e) => setFormData(prev => ({ ...prev, cor: e.target.value }))}
                        className="flex-1"
                        placeholder="#000000"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="numeroMinimoDias" className="text-right">
                      Dias Mínimos
                    </Label>
                    <Input
                      id="numeroMinimoDias"
                      type="number"
                      min="0"
                      value={formData.numeroMinimoDias}
                      onChange={(e) => setFormData(prev => ({ ...prev, numeroMinimoDias: parseInt(e.target.value) || 0 }))}
                      className="col-span-3"
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label className="text-right">
                      Datas Letivas
                    </Label>
                    <div className="col-span-3 flex items-center space-x-2">
                      <Checkbox
                        checked={formData.datasLetivas}
                        onCheckedChange={(checked) => 
                          setFormData(prev => ({ ...prev, datasLetivas: checked as boolean }))
                        }
                      />
                      <Label className="text-sm">
                        Considerar como datas letivas
                      </Label>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 items-start gap-4">
                    <Label className="text-right pt-2">
                      Dias Válidos
                    </Label>
                    <div className="col-span-3 grid grid-cols-4 gap-2">
                      {diasSemana.map((dia, index) => (
                        <div key={dia} className="flex items-center space-x-1">
                          <Checkbox
                            checked={formData.diasSemanaValidos[index]}
                            onCheckedChange={(checked) => {
                              const newDias = [...formData.diasSemanaValidos]
                              newDias[index] = checked as boolean
                              setFormData(prev => ({ ...prev, diasSemanaValidos: newDias }))
                            }}
                          />
                          <Label className="text-xs">{dia}</Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Categoria'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
