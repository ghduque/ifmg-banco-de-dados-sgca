'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Edit, Trash2, AlertTriangle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { AnoLetivo } from '@/types'
import { mockAnosLetivos } from '@/lib/mock-data'

export default function AnosLetivosPage() {
  const [anosLetivos, setAnosLetivos] = useState<AnoLetivo[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<AnoLetivo | null>(null)
  const [formData, setFormData] = useState({
    ano: '',
    descricao: '',
    dataInicio: '',
    dataFim: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    // Simular carregamento dos dados
    setAnosLetivos(mockAnosLetivos)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação básica
    if (new Date(formData.dataInicio) >= new Date(formData.dataFim)) {
      toast({
        title: 'Erro de validação',
        description: 'A data de início deve ser anterior à data de fim.',
        variant: 'destructive'
      })
      return
    }

    if (editingItem) {
      // Atualizar
      setAnosLetivos(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, ...formData, ano: parseInt(formData.ano) }
          : item
      ))
      toast({
        title: 'Ano letivo atualizado',
        description: 'As alterações foram salvas com sucesso.'
      })
    } else {
      // Criar novo
      const newItem: AnoLetivo = {
        id: Date.now().toString(),
        ano: parseInt(formData.ano),
        descricao: formData.descricao,
        dataInicio: formData.dataInicio,
        dataFim: formData.dataFim,
        pendencias: []
      }
      setAnosLetivos(prev => [...prev, newItem])
      toast({
        title: 'Ano letivo criado',
        description: 'O novo ano letivo foi adicionado com sucesso.'
      })
    }

    setIsDialogOpen(false)
    setEditingItem(null)
    setFormData({ ano: '', descricao: '', dataInicio: '', dataFim: '' })
  }

  const handleEdit = (item: AnoLetivo) => {
    setEditingItem(item)
    setFormData({
      ano: item.ano.toString(),
      descricao: item.descricao,
      dataInicio: item.dataInicio,
      dataFim: item.dataFim
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setAnosLetivos(prev => prev.filter(item => item.id !== id))
    toast({
      title: 'Ano letivo excluído',
      description: 'O ano letivo foi removido com sucesso.'
    })
  }

  const openNewDialog = () => {
    setEditingItem(null)
    setFormData({ ano: '', descricao: '', dataInicio: '', dataFim: '' })
    setIsDialogOpen(true)
  }

  return (
    <div className="flex min-h-screen">
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Anos Letivos</h2>
                <p className="text-muted-foreground">
                  Gerencie os anos letivos do sistema
                </p>
              </div>
              <Button onClick={openNewDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Ano Letivo
              </Button>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Lista de Anos Letivos</CardTitle>
                <CardDescription>
                  Visualize e gerencie todos os anos letivos cadastrados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ano</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Data de Início</TableHead>
                      <TableHead>Data de Fim</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {anosLetivos.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.ano}</TableCell>
                        <TableCell>{item.descricao}</TableCell>
                        <TableCell>{new Date(item.dataInicio).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>{new Date(item.dataFim).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>
                          {item.pendencias && item.pendencias.length > 0 ? (
                            <Badge variant="destructive" className="flex items-center w-fit">
                              <AlertTriangle className="mr-1 h-3 w-3" />
                              Pendências
                            </Badge>
                          ) : (
                            <Badge variant="default">Ativo</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir o ano letivo {item.ano}? 
                                    Esta ação não pode ser desfeita.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Dialog para criar/editar */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? 'Editar Ano Letivo' : 'Novo Ano Letivo'}
                </DialogTitle>
                <DialogDescription>
                  {editingItem 
                    ? 'Faça as alterações necessárias no ano letivo.'
                    : 'Preencha os dados para criar um novo ano letivo.'
                  }
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="ano" className="text-right">
                      Ano
                    </Label>
                    <Input
                      id="ano"
                      type="number"
                      value={formData.ano}
                      onChange={(e) => setFormData(prev => ({ ...prev, ano: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="descricao" className="text-right">
                      Descrição
                    </Label>
                    <Textarea
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dataInicio" className="text-right">
                      Data Início
                    </Label>
                    <Input
                      id="dataInicio"
                      type="date"
                      value={formData.dataInicio}
                      onChange={(e) => setFormData(prev => ({ ...prev, dataInicio: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dataFim" className="text-right">
                      Data Fim
                    </Label>
                    <Input
                      id="dataFim"
                      type="date"
                      value={formData.dataFim}
                      onChange={(e) => setFormData(prev => ({ ...prev, dataFim: e.target.value }))}
                      className="col-span-3"
                      required
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingItem ? 'Salvar Alterações' : 'Criar Ano Letivo'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
