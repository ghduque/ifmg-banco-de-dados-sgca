export interface AnoLetivo {
  id: string
  ano: number
  descricao: string
  dataInicio: string
  dataFim: string
  pendencias?: string[]
}

export interface Calendario {
  id: string
  anoLetivoId: string
  nome: string
  sincronizado: boolean
  pendencias?: string[]
}

export interface CategoriaData {
  id: string
  calendarioId: string
  nome: string
  cor: string
  numeroMinimoDias: number
  datasLetivas: boolean
  diasSemanaValidos: boolean[]
}

export interface Data {
  id: string
  categoriaDataId: string
  descricao: string
  inicio: string
  fim: string
  diasFaltantes?: number
}

export interface Reposicao {
  id: string
  calendarioId: string
  diaPerdido: string
  diaReposto: string
}

export interface EventoObrigatorio {
  id: string
  descricao: string
  numeroOcorrencias: number
}

export interface PrazoEvento {
  id: string
  anoLetivoId: string
  descricao: string
  dataInicio: string
  dataFim: string
  tipoEvento: 'obrigatorio' | 'opcional'
  eventoObrigatorioId?: string
}

export interface DiasLetivos {
  segunda: number
  terca: number
  quarta: number
  quinta: number
  sexta: number
}
