'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Calendar, CalendarDays, Clock, FileText, GraduationCap, Home, Menu, Settings, Users, BarChart3, BookOpen } from 'lucide-react'

const navigation = [
  {
    name: 'Dashboard',
    href: '/',
    icon: Home
  },
  {
    name: 'Anos Letivos',
    href: '/anos-letivos',
    icon: GraduationCap
  },
  {
    name: 'Calendários',
    href: '/calendarios',
    icon: Calendar
  },
  {
    name: 'Categorias de Datas',
    href: '/categorias-datas',
    icon: BookOpen
  },
  {
    name: 'Datas',
    href: '/datas',
    icon: CalendarDays
  },
  {
    name: 'Equalização',
    href: '/equalizacao',
    icon: BarChart3
  },
  {
    name: 'Eventos Obrigatórios',
    href: '/eventos-obrigatorios',
    icon: Users
  },
  {
    name: 'Prazos e Eventos',
    href: '/prazos-eventos',
    icon: Clock
  },
  {
    name: 'Visualização',
    href: '/visualizacao',
    icon: FileText
  }
]

interface SidebarProps {
  className?: string
}

export function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname()

  return (
    <div className={cn('pb-12', className)}>
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <div className="flex items-center mb-6">
            <GraduationCap className="h-8 w-8 text-primary mr-2" />
            <div>
              <h2 className="text-lg font-semibold">SGCA</h2>
              <p className="text-xs text-muted-foreground">Sistema de Gestão</p>
            </div>
          </div>
          <div className="space-y-1">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button
                  variant={pathname === item.href ? 'secondary' : 'ghost'}
                  className="w-full justify-start"
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.name}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export function MobileSidebar() {
  const [open, setOpen] = useState(false)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden"
        >
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle Menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="pr-0">
        <ScrollArea className="my-4 h-[calc(100vh-8rem)] pb-10 pl-6">
          <Sidebar />
        </ScrollArea>
      </SheetContent>
    </Sheet>
  )
}
