-- Melhorias no Trabalho 2 (SQL)




-- Criação do banco de dados
-- Garante que o banco de dados 'sistema_academico_ext' seja removido se já existir, para uma criação limpa.
DROP DATABASE IF EXISTS sistema_academico_ext;
CREATE DATABASE sistema_academico_ext;
\c sistema_academico_ext

-- Tabela: periodo_academico
-- Armazena informações sobre os períodos acadêmicos, como ano letivo, datas de início e fim.
CREATE TABLE periodo_academico (
    id_periodo INT PRIMARY KEY, -- Identificador único do período acadêmico (ex: 2023, 2024)
    nome_periodo VARCHAR(120) NOT NULL, -- Nome descritivo do período (ex: 'Período Acadêmico 2023')
    data_inicio DATE NOT NULL, -- Data de início do período
    data_fim DATE NOT NULL, -- Data de término do período
    -- Restrição para garantir que a data de início seja anterior à data de fim.
    CHECK (data_inicio < data_fim)
);

-- Tabela: plano_ensino
-- Contém os planos de ensino associados a um período acadêmico específico.
CREATE TABLE plano_ensino (
    id_plano SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável do plano de ensino
    id_periodo INT NOT NULL, -- Chave estrangeira referenciando o período acadêmico
    titulo VARCHAR(120) NOT NULL, -- Título do plano de ensino (ex: 'Plano de Ensino - Licenciatura')
    publicado BOOLEAN DEFAULT FALSE, -- Indica se o plano de ensino está publicado (TRUE) ou em rascunho (FALSE)
    -- Chave estrangeira para 'periodo_academico'. Se um período for excluído, seus planos de ensino também serão.
    FOREIGN KEY (id_periodo) REFERENCES periodo_academico(id_periodo) ON DELETE CASCADE
);

-- Tabela: tipo_dia
-- Define diferentes categorias de dias dentro de um plano de ensino (ex: 'Dias Letivos', 'Recesso', 'Feriado').
CREATE TABLE tipo_dia (
    id_tipo SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável do tipo de dia
    id_plano INT NOT NULL, -- Chave estrangeira referenciando o plano de ensino ao qual o tipo de dia pertence
    rotulo VARCHAR(100) NOT NULL, -- Rótulo descritivo do tipo de dia (ex: 'Dias Letivos Regular')
    cor CHAR(7) NOT NULL, -- Código de cor em formato hexadecimal (#RRGGBB) para representação visual
    dias_minimos INT DEFAULT 0, -- Número mínimo de dias para este tipo (útil para dias letivos)
    academico BOOLEAN NOT NULL, -- Indica se o dia é considerado acadêmico (TRUE) ou não (FALSE)
    dom BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a domingo
    seg BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a segunda-feira
    ter BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a terça-feira
    qua BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a quarta-feira
    qui BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a quinta-feira
    sex BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a sexta-feira
    sab BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a sábado
    -- Chave estrangeira para 'plano_ensino'. Se um plano for excluído, seus tipos de dia também serão.
    FOREIGN KEY (id_plano) REFERENCES plano_ensino(id_plano) ON DELETE CASCADE,
    -- Garante que a combinação de plano e cor seja única, evitando cores duplicadas para o mesmo plano.
    UNIQUE (id_plano, cor)
);

-- Tabela: faixa_data
-- Define intervalos de datas específicos que se enquadram em um 'tipo_dia' (ex: 'Semestre 1 - Aulas').
CREATE TABLE faixa_data (
    id_faixa SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável da faixa de data
    id_tipo INT NOT NULL, -- Chave estrangeira referenciando o tipo de dia ao qual esta faixa pertence
    descricao VARCHAR(100) NOT NULL, -- Descrição da faixa de data (ex: 'Semestre 1 - Aulas')
    inicio DATE NOT NULL, -- Data de início da faixa
    fim DATE NOT NULL, -- Data de término da faixa
    -- Chave estrangeira para 'tipo_dia'. Se um tipo de dia for excluído, suas faixas de data também serão.
    FOREIGN KEY (id_tipo) REFERENCES tipo_dia(id_tipo) ON DELETE CASCADE,
    -- Restrição para garantir que a data de início seja menor ou igual à data de fim.
    CHECK (inicio <= fim)
);

-- Tabela: reposicao_dia
-- Registra dias de aula perdidos e seus respectivos dias de reposição.
CREATE TABLE reposicao_dia (
    id_reposicao SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável da reposição
    id_periodo INT NOT NULL, -- Chave estrangeira referenciando o período acadêmico da reposição
    dia_perdido DATE NOT NULL, -- Data do dia de aula que foi perdido
    dia_reposto DATE NOT NULL, -- Data do dia em que a aula foi reposta
    -- Chave estrangeira para 'periodo_academico'. Se um período for excluído, suas reposições também serão.
    FOREIGN KEY (id_periodo) REFERENCES periodo_academico(id_periodo) ON DELETE CASCADE
);

-- Tabela: atividade_base
-- Define atividades obrigatórias ou recorrentes que devem ser realizadas em um período.
CREATE TABLE atividade_base (
    id_base SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável da atividade base
    nome_atividade VARCHAR(100) NOT NULL UNIQUE, -- Nome da atividade (ex: 'Conselho de Classe Final'), deve ser único.
    vezes_requeridas INT DEFAULT 1 -- Número de vezes que a atividade é requerida em um período
);

-- Tabela: atividade_realizada
-- Registra as ocorrências de atividades ou eventos específicos em um período acadêmico.
CREATE TABLE atividade_realizada (
    id_evento SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável do evento/atividade realizada
    id_periodo INT NOT NULL, -- Chave estrangeira referenciando o período acadêmico do evento
    descricao VARCHAR(100) NOT NULL, -- Descrição detalhada do evento (ex: 'Conselho de Classe 1')
    inicio DATE NOT NULL, -- Data de início do evento
    fim DATE NOT NULL, -- Data de término do evento
    id_base INT, -- Chave estrangeira opcional referenciando uma atividade base (se for uma ocorrência de uma atividade obrigatória)
    -- Chave estrangeira para 'periodo_academico'. Se um período for excluído, suas atividades realizadas também serão.
    FOREIGN KEY (id_periodo) REFERENCES periodo_academico(id_periodo) ON DELETE CASCADE,
    -- Chave estrangeira para 'atividade_base'. Se uma atividade base for excluída, o id_base será definido como NULL.
    FOREIGN KEY (id_base) REFERENCES atividade_base(id_base) ON DELETE SET NULL,
    -- Restrição para garantir que a data de início seja menor ou igual à data de fim.
    CHECK (inicio <= fim)
);

-- Inserção de dados iniciais para teste e demonstração.

-- Dados para a tabela periodo_academico
INSERT INTO periodo_academico (id_periodo, nome_periodo, data_inicio, data_fim) VALUES
(2023, 'Período Acadêmico 2023', '2023-01-15', '2023-12-10'),
(2024, 'Período Acadêmico 2024', '2024-02-05', '2024-12-20');

-- Dados para a tabela plano_ensino
INSERT INTO plano_ensino (id_periodo, titulo, publicado) VALUES
(2024, 'Plano de Ensino - Licenciatura', TRUE),
(2024, 'Plano de Ensino - Técnico Integrado', TRUE),
(2024, 'Plano de Ensino - Pós-Graduação', FALSE);

-- Dados para a tabela tipo_dia
INSERT INTO tipo_dia (id_plano, rotulo, cor, dias_minimos, academico, dom, seg, ter, qua, qui, sex, sab) VALUES
(1, 'Dias Letivos Regular', '#00aaff', 90, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE),
(1, 'Recesso Acadêmico', '#ff6600', 0, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE),
(1, 'Feriado Nacional', '#cc0000', 0, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

-- Dados para a tabela faixa_data
INSERT INTO faixa_data (id_tipo, descricao, inicio, fim) VALUES
(1, 'Semestre 1 - Aulas', '2024-02-19', '2024-07-10'),
(1, 'Semestre 2 - Aulas', '2024-08-05', '2024-12-10'),
(2, 'Recesso de Julho', '2024-07-11', '2024-08-04'),
(3, 'Dia da República', '2024-11-15', '2024-11-15');

-- Dados para a tabela reposicao_dia
INSERT INTO reposicao_dia (id_periodo, dia_perdido, dia_reposto) VALUES
(2024, '2024-11-15', '2024-11-13');

-- Dados para a tabela atividade_base
INSERT INTO atividade_base (nome_atividade, vezes_requeridas) VALUES
('Conselho de Classe Final', 2),
('Planejamento Institucional', 1),
('Avaliação Institucional', 1);

-- Dados para a tabela atividade_realizada
INSERT INTO atividade_realizada (id_periodo, descricao, inicio, fim, id_base) VALUES
(2024, 'Conselho de Classe 1', '2024-07-12', '2024-07-12', 1),
(2024, 'Planejamento Anual', '2024-01-20', '2024-01-20', 2),
(2024, 'Avaliação Institucional Interna', '2024-12-12', '2024-12-12', 3),
(2024, 'Semana de Tecnologia', '2024-09-18', '2024-09-20', NULL);

-- Consultas de teste e demonstração com melhorias e comentários.

-- Consulta 1: Calcular o total de dias letivos para cada plano de ensino.
-- Esta consulta soma a duração das faixas de dados que são classificadas como 'acadêmicas' 
-- para cada plano de ensino, fornecendo o número total de dias letivos.
SELECT
    p.titulo AS 

    "Plano de Ensino",
    SUM(f.fim - f.inicio + 1) AS "Dias Letivos"
FROM
    plano_ensino p
JOIN
    tipo_dia td ON td.id_plano = p.id_plano
JOIN
    faixa_data f ON f.id_tipo = td.id_tipo
WHERE
    td.academico = TRUE
GROUP BY
    p.titulo
ORDER BY
    p.titulo;

-- Consulta 2: Verificar o status de atividades obrigatórias para um período específico.
-- Esta consulta compara o número de vezes que uma atividade base foi realizada com o número
-- de vezes que ela é requerida, indicando se há pendências.
SELECT
    ab.nome_atividade AS "Atividade Obrigatória",
    ab.vezes_requeridas AS "Vezes Requeridas",
    COUNT(ar.id_evento) AS "Realizadas",
    CASE
        WHEN COUNT(ar.id_evento) < ab.vezes_requeridas THEN 'Pendência'
        ELSE 'Concluído'
    END AS "Status"
FROM
    atividade_base ab
LEFT JOIN
    atividade_realizada ar ON ar.id_base = ab.id_base AND ar.id_periodo = 2024
GROUP BY
    ab.nome_atividade, ab.vezes_requeridas
ORDER BY
    ab.nome_atividade;

-- Consulta 3: Listar faixas de datas não acadêmicas (feriados e recessos).
-- Esta consulta filtra as faixas de datas que não são consideradas acadêmicas e as categoriza
-- como 'Feriado' ou 'Recesso' com base no rótulo do tipo de dia.
SELECT
    f.descricao AS "Descrição da Faixa",
    f.inicio AS "Início",
    f.fim AS "Fim",
    CASE
        WHEN td.rotulo LIKE '%Feriado%' THEN 'Feriado'
        ELSE 'Recesso'
    END AS "Tipo"
FROM
    faixa_data f
JOIN
    tipo_dia td ON td.id_tipo = f.id_tipo
WHERE
    td.academico = FALSE
ORDER BY
    f.inicio;

-- Consulta 4: Identificar atividades realizadas fora do período acadêmico definido.
-- Esta consulta verifica se alguma atividade registrada ocorreu fora das datas de início e fim
-- do período acadêmico ao qual está associada, o que pode indicar um erro de registro.
SELECT
    ar.descricao AS "Atividade",
    ar.inicio AS "Data de Início da Atividade",
    pa.nome_periodo AS "Período Acadêmico Associado",
    pa.data_inicio AS "Início do Período",
    pa.data_fim AS "Fim do Período"
FROM
    atividade_realizada ar
JOIN
    periodo_academico pa ON pa.id_periodo = ar.id_periodo
WHERE
    ar.inicio < pa.data_inicio OR ar.inicio > pa.data_fim
ORDER BY
    ar.inicio;

-- Consulta 5: Analisar dias de semana de dias perdidos e repostos para reposições.
-- Esta consulta extrai o dia da semana (0=Domingo, 6=Sábado) para o dia perdido e o dia reposto
-- em registros de reposição, útil para verificar a consistência dos dias da semana.
SELECT
    r.dia_perdido AS "Dia Perdido",
    r.dia_reposto AS "Dia Reposto",
    EXTRACT(DOW FROM r.dia_perdido) AS "Dia da Semana Perdido (0=Dom)",
    EXTRACT(DOW FROM r.dia_reposto) AS "Dia da Semana Reposto (0=Dom)"
FROM
    reposicao_dia r
WHERE
    r.id_periodo = 2024
ORDER BY
    r.dia_perdido;

-- Melhorias Adicionais Sugeridas:

-- 1. Adicionar índices para otimização de consultas:
-- Índices podem acelerar a recuperação de dados em colunas frequentemente usadas em cláusulas WHERE ou JOIN.
CREATE INDEX idx_plano_ensino_id_periodo ON plano_ensino (id_periodo);
CREATE INDEX idx_tipo_dia_id_plano ON tipo_dia (id_plano);
CREATE INDEX idx_faixa_data_id_tipo ON faixa_data (id_tipo);
CREATE INDEX idx_reposicao_dia_id_periodo ON reposicao_dia (id_periodo);
CREATE INDEX idx_atividade_realizada_id_periodo ON atividade_realizada (id_periodo);
CREATE INDEX idx_atividade_realizada_id_base ON atividade_realizada (id_base);

-- 2. Adicionar uma visão para simplificar a consulta de dias letivos por plano de ensino.
-- Visões são tabelas virtuais que simplificam consultas complexas e podem ser usadas como tabelas reais.
CREATE VIEW dias_letivos_por_plano AS
SELECT
    p.titulo AS plano_ensino_titulo,
    SUM(f.fim - f.inicio + 1) AS total_dias_letivos
FROM
    plano_ensino p
JOIN
    tipo_dia td ON td.id_plano = p.id_plano
JOIN
    faixa_data f ON f.id_tipo = td.id_tipo
WHERE
    td.academico = TRUE
GROUP BY
    p.titulo;

-- Exemplo de uso da visão:
-- SELECT * FROM dias_letivos_por_plano;

-- 3. Adicionar uma função para verificar a validade de um período acadêmico.
-- Funções podem encapsular lógica de negócios e serem reutilizadas em consultas ou outras funções.
CREATE OR REPLACE FUNCTION verificar_periodo_valido(p_id_periodo INT) RETURNS BOOLEAN AS $$
DECLARE
    v_data_inicio DATE;
    v_data_fim DATE;
BEGIN
    SELECT data_inicio, data_fim INTO v_data_inicio, v_data_fim
    FROM periodo_academico
    WHERE id_periodo = p_id_periodo;

    IF v_data_inicio IS NULL THEN
        RETURN FALSE; -- Período não encontrado
    END IF;

    RETURN v_data_inicio < v_data_fim;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT verificar_periodo_valido(2024);
-- SELECT verificar_periodo_valido(9999);

-- 4. Adicionar um gatilho para garantir que a data de reposição não seja anterior à data perdida.
-- Gatilhos são blocos de código que são executados automaticamente em resposta a eventos (INSERT, UPDATE, DELETE).
CREATE OR REPLACE FUNCTION checar_data_reposicao() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.dia_reposto < NEW.dia_perdido THEN
        RAISE EXCEPTION 'A data de reposição (%) não pode ser anterior à data do dia perdido (%).',
                        NEW.dia_reposto, NEW.dia_perdido;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_checar_data_reposicao
BEFORE INSERT OR UPDATE ON reposicao_dia
FOR EACH ROW
EXECUTE FUNCTION checar_data_reposicao();

-- Exemplo de teste do gatilho (tentará inserir e falhará):
-- INSERT INTO reposicao_dia (id_periodo, dia_perdido, dia_reposto) VALUES (2024, '2024-11-20', '2024-11-19');

-- 5. Adicionar uma regra para evitar a exclusão de planos de ensino publicados.
-- Regras (RULES) são uma forma de reescrever consultas, mas são menos flexíveis que gatilhos para validações complexas.
-- Para este caso, um gatilho seria mais robusto, mas a regra é incluída para demonstração.
CREATE RULE no_delete_published_plan AS ON DELETE TO plano_ensino
WHERE OLD.publicado = TRUE
DO INSTEAD
    SELECT RAISE EXCEPTION 'Não é permitido excluir planos de ensino publicados (ID: %).', OLD.id_plano;

-- Exemplo de teste da regra (tentará excluir e falhará):
-- DELETE FROM plano_ensino WHERE id_plano = 1;

-- 6. Adicionar uma função para calcular a duração de um evento em dias.
CREATE OR REPLACE FUNCTION calcular_duracao_evento(p_inicio DATE, p_fim DATE) RETURNS INT AS $$
BEGIN
    RETURN p_fim - p_inicio + 1;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT descricao, inicio, fim, calcular_duracao_evento(inicio, fim) AS duracao_dias FROM atividade_realizada;

-- 7. Adicionar uma visão para listar atividades realizadas com suas durações.
CREATE VIEW atividades_com_duracao AS
SELECT
    ar.descricao,
    ar.inicio,
    ar.fim,
    calcular_duracao_evento(ar.inicio, ar.fim) AS duracao_dias,
    pa.nome_periodo
FROM
    atividade_realizada ar
JOIN
    periodo_academico pa ON ar.id_periodo = pa.id_periodo;

-- Exemplo de uso da visão:
-- SELECT * FROM atividades_com_duracao;

-- 8. Adicionar uma função para obter o nome do dia da semana a partir de uma data.
CREATE OR REPLACE FUNCTION get_nome_dia_semana(p_data DATE) RETURNS VARCHAR AS $$
BEGIN
    RETURN CASE EXTRACT(DOW FROM p_data)
        WHEN 0 THEN 'Domingo'
        WHEN 1 THEN 'Segunda-feira'
        WHEN 2 THEN 'Terça-feira'
        WHEN 3 THEN 'Quarta-feira'
        WHEN 4 THEN 'Quinta-feira'
        WHEN 5 THEN 'Sexta-feira'
        WHEN 6 THEN 'Sábado'
    END;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT dia_perdido, get_nome_dia_semana(dia_perdido) AS dia_semana_perdido FROM reposicao_dia WHERE id_periodo = 2024;

-- 9. Adicionar uma visão para listar reposições com nomes dos dias da semana.
CREATE VIEW reposicoes_com_dias_semana AS
SELECT
    r.dia_perdido,
    get_nome_dia_semana(r.dia_perdido) AS dia_semana_perdido,
    r.dia_reposto,
    get_nome_dia_semana(r.dia_reposto) AS dia_semana_reposto,
    pa.nome_periodo
FROM
    reposicao_dia r
JOIN
    periodo_academico pa ON r.id_periodo = pa.id_periodo;

-- Exemplo de uso da visão:
-- SELECT * FROM reposicoes_com_dias_semana;

-- 10. Adicionar uma função para verificar se uma data está dentro de uma faixa de datas.
CREATE OR REPLACE FUNCTION is_date_in_range(p_date DATE, p_start_date DATE, p_end_date DATE) RETURNS BOOLEAN AS $$
BEGIN
    RETURN p_date BETWEEN p_start_date AND p_end_date;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT descricao, inicio, fim, is_date_in_range('2024-07-15', inicio, fim) AS esta_em_faixa FROM faixa_data;

-- 11. Adicionar uma visão para listar planos de ensino que não estão publicados.
CREATE VIEW planos_nao_publicados AS
SELECT
    id_plano,
    titulo,
    nome_periodo
FROM
    plano_ensino pe
JOIN
    periodo_academico pa ON pe.id_periodo = pa.id_periodo
WHERE
    publicado = FALSE;

-- Exemplo de uso da visão:
-- SELECT * FROM planos_nao_publicados;

-- 12. Adicionar uma função para contar o número de atividades realizadas para uma atividade base específica em um período.
CREATE OR REPLACE FUNCTION contar_atividades_realizadas_base(p_id_base INT, p_id_periodo INT) RETURNS BIGINT AS $$
DECLARE
    v_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM atividade_realizada
    WHERE id_base = p_id_base AND id_periodo = p_id_periodo;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT nome_atividade, vezes_requeridas, contar_atividades_realizadas_base(id_base, 2024) AS realizadas_no_periodo FROM atividade_base;

-- 13. Adicionar um gatilho para atualizar automaticamente o status de publicação de um plano de ensino
-- se todos os seus tipos de dia tiverem dias_minimos > 0.
-- Este gatilho é um exemplo mais complexo que pode ser adaptado conforme a lógica de negócio.
CREATE OR REPLACE FUNCTION atualizar_status_publicacao_plano() RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        -- Verifica se todos os tipos de dia associados a este plano têm dias_minimos > 0
        -- e se o plano ainda não está publicado.
        IF NOT EXISTS (
            SELECT 1
            FROM tipo_dia
            WHERE id_plano = NEW.id_plano AND dias_minimos <= 0
        ) AND NEW.publicado = FALSE THEN
            UPDATE plano_ensino
            SET publicado = TRUE
            WHERE id_plano = NEW.id_plano;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Este gatilho seria acionado na tabela tipo_dia, pois é onde os dias_minimos são definidos.
-- CREATE TRIGGER trg_atualizar_publicacao_plano
-- AFTER INSERT OR UPDATE ON tipo_dia
-- FOR EACH ROW
-- EXECUTE FUNCTION atualizar_status_publicacao_plano();

-- Nota: A ativação deste gatilho pode requerer uma revisão da lógica de negócio, pois a publicação
-- de um plano pode depender de múltiplos fatores além dos dias_minimos.

-- Fim das melhorias.


-- Melhorias no Trabalho 2 (SQL)

-- Criação do banco de dados
-- Garante que o banco de dados 'sistema_academico_ext' seja removido se já existir, para uma criação limpa.
DROP DATABASE IF EXISTS sistema_academico_ext;
CREATE DATABASE sistema_academico_ext;
\c sistema_academico_ext

-- Tabela: periodo_academico
-- Armazena informações sobre os períodos acadêmicos, como ano letivo, datas de início e fim.
CREATE TABLE periodo_academico (
    id_periodo INT PRIMARY KEY, -- Identificador único do período acadêmico (ex: 2023, 2024)
    nome_periodo VARCHAR(120) NOT NULL, -- Nome descritivo do período (ex: 'Período Acadêmico 2023')
    data_inicio DATE NOT NULL, -- Data de início do período
    data_fim DATE NOT NULL, -- Data de término do período
    -- Restrição para garantir que a data de início seja anterior à data de fim.
    CHECK (data_inicio < data_fim)
);

-- Tabela: plano_ensino
-- Contém os planos de ensino associados a um período acadêmico específico.
CREATE TABLE plano_ensino (
    id_plano SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável do plano de ensino
    id_periodo INT NOT NULL, -- Chave estrangeira referenciando o período acadêmico
    titulo VARCHAR(120) NOT NULL, -- Título do plano de ensino (ex: 'Plano de Ensino - Licenciatura')
    publicado BOOLEAN DEFAULT FALSE, -- Indica se o plano de ensino está publicado (TRUE) ou em rascunho (FALSE)
    -- Chave estrangeira para 'periodo_academico'. Se um período for excluído, seus planos de ensino também serão.
    FOREIGN KEY (id_periodo) REFERENCES periodo_academico(id_periodo) ON DELETE CASCADE
);

-- Tabela: tipo_dia
-- Define diferentes categorias de dias dentro de um plano de ensino (ex: 'Dias Letivos', 'Recesso', 'Feriado').
CREATE TABLE tipo_dia (
    id_tipo SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável do tipo de dia
    id_plano INT NOT NULL, -- Chave estrangeira referenciando o plano de ensino ao qual o tipo de dia pertence
    rotulo VARCHAR(100) NOT NULL, -- Rótulo descritivo do tipo de dia (ex: 'Dias Letivos Regular')
    cor CHAR(7) NOT NULL, -- Código de cor em formato hexadecimal (#RRGGBB) para representação visual
    dias_minimos INT DEFAULT 0, -- Número mínimo de dias para este tipo (útil para dias letivos)
    academico BOOLEAN NOT NULL, -- Indica se o dia é considerado acadêmico (TRUE) ou não (FALSE)
    dom BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a domingo
    seg BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a segunda-feira
    ter BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a terça-feira
    qua BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a quarta-feira
    qui BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a quinta-feira
    sex BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a sexta-feira
    sab BOOLEAN NOT NULL, -- Indica se este tipo de dia se aplica a sábado
    -- Chave estrangeira para 'plano_ensino'. Se um plano for excluído, seus tipos de dia também serão.
    FOREIGN KEY (id_plano) REFERENCES plano_ensino(id_plano) ON DELETE CASCADE,
    -- Garante que a combinação de plano e cor seja única, evitando cores duplicadas para o mesmo plano.
    UNIQUE (id_plano, cor)
);

-- Tabela: faixa_data
-- Define intervalos de datas específicos que se enquadram em um 'tipo_dia' (ex: 'Semestre 1 - Aulas').
CREATE TABLE faixa_data (
    id_faixa SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável da faixa de data
    id_tipo INT NOT NULL, -- Chave estrangeira referenciando o tipo de dia ao qual esta faixa pertence
    descricao VARCHAR(100) NOT NULL, -- Descrição da faixa de data (ex: 'Semestre 1 - Aulas')
    inicio DATE NOT NULL, -- Data de início da faixa
    fim DATE NOT NULL, -- Data de término da faixa
    -- Chave estrangeira para 'tipo_dia'. Se um tipo de dia for excluído, suas faixas de data também serão.
    FOREIGN KEY (id_tipo) REFERENCES tipo_dia(id_tipo) ON DELETE CASCADE,
    -- Restrição para garantir que a data de início seja menor ou igual à data de fim.
    CHECK (inicio <= fim)
);

-- Tabela: reposicao_dia
-- Registra dias de aula perdidos e seus respectivos dias de reposição.
CREATE TABLE reposicao_dia (
    id_reposicao SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável da reposição
    id_periodo INT NOT NULL, -- Chave estrangeira referenciando o período acadêmico da reposição
    dia_perdido DATE NOT NULL, -- Data do dia de aula que foi perdido
    dia_reposto DATE NOT NULL, -- Data do dia em que a aula foi reposta
    -- Chave estrangeira para 'periodo_academico'. Se um período for excluído, suas reposições também serão.
    FOREIGN KEY (id_periodo) REFERENCES periodo_academico(id_periodo) ON DELETE CASCADE
);

-- Tabela: atividade_base
-- Define atividades obrigatórias ou recorrentes que devem ser realizadas em um período.
CREATE TABLE atividade_base (
    id_base SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável da atividade base
    nome_atividade VARCHAR(100) NOT NULL UNIQUE, -- Nome da atividade (ex: 'Conselho de Classe Final'), deve ser único.
    vezes_requeridas INT DEFAULT 1 -- Número de vezes que a atividade é requerida em um período
);

-- Tabela: atividade_realizada
-- Registra as ocorrências de atividades ou eventos específicos em um período acadêmico.
CREATE TABLE atividade_realizada (
    id_evento SERIAL PRIMARY KEY, -- Identificador único e auto-incrementável do evento/atividade realizada
    id_periodo INT NOT NULL, -- Chave estrangeira referenciando o período acadêmico do evento
    descricao VARCHAR(100) NOT NULL, -- Descrição detalhada do evento (ex: 'Conselho de Classe 1')
    inicio DATE NOT NULL, -- Data de início do evento
    fim DATE NOT NULL, -- Data de término do evento
    id_base INT, -- Chave estrangeira opcional referenciando uma atividade base (se for uma ocorrência de uma atividade obrigatória)
    -- Chave estrangeira para 'periodo_academico'. Se um período for excluído, suas atividades realizadas também serão.
    FOREIGN KEY (id_periodo) REFERENCES periodo_academico(id_periodo) ON DELETE CASCADE,
    -- Chave estrangeira para 'atividade_base'. Se uma atividade base for excluída, o id_base será definido como NULL.
    FOREIGN KEY (id_base) REFERENCES atividade_base(id_base) ON DELETE SET NULL,
    -- Restrição para garantir que a data de início seja menor ou igual à data de fim.
    CHECK (inicio <= fim)
);

-- Inserção de dados iniciais para teste e demonstração.

-- Dados para a tabela periodo_academico
INSERT INTO periodo_academico (id_periodo, nome_periodo, data_inicio, data_fim) VALUES
(2023, 'Período Acadêmico 2023', '2023-01-15', '2023-12-10'),
(2024, 'Período Acadêmico 2024', '2024-02-05', '2024-12-20');

-- Dados para a tabela plano_ensino
INSERT INTO plano_ensino (id_periodo, titulo, publicado) VALUES
(2024, 'Plano de Ensino - Licenciatura', TRUE),
(2024, 'Plano de Ensino - Técnico Integrado', TRUE),
(2024, 'Plano de Ensino - Pós-Graduação', FALSE);

-- Dados para a tabela tipo_dia
INSERT INTO tipo_dia (id_plano, rotulo, cor, dias_minimos, academico, dom, seg, ter, qua, qui, sex, sab) VALUES
(1, 'Dias Letivos Regular', '#00aaff', 90, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE),
(1, 'Recesso Acadêmico', '#ff6600', 0, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE),
(1, 'Feriado Nacional', '#cc0000', 0, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

-- Dados para a tabela faixa_data
INSERT INTO faixa_data (id_tipo, descricao, inicio, fim) VALUES
(1, 'Semestre 1 - Aulas', '2024-02-19', '2024-07-10'),
(1, 'Semestre 2 - Aulas', '2024-08-05', '2024-12-10'),
(2, 'Recesso de Julho', '2024-07-11', '2024-08-04'),
(3, 'Dia da República', '2024-11-15', '2024-11-15');

-- Dados para a tabela reposicao_dia
INSERT INTO reposicao_dia (id_periodo, dia_perdido, dia_reposto) VALUES
(2024, '2024-11-15', '2024-11-13');

-- Dados para a tabela atividade_base
INSERT INTO atividade_base (nome_atividade, vezes_requeridas) VALUES
('Conselho de Classe Final', 2),
('Planejamento Institucional', 1),
('Avaliação Institucional', 1);

-- Dados para a tabela atividade_realizada
INSERT INTO atividade_realizada (id_periodo, descricao, inicio, fim, id_base) VALUES
(2024, 'Conselho de Classe 1', '2024-07-12', '2024-07-12', 1),
(2024, 'Planejamento Anual', '2024-01-20', '2024-01-20', 2),
(2024, 'Avaliação Institucional Interna', '2024-12-12', '2024-12-12', 3),
(2024, 'Semana de Tecnologia', '2024-09-18', '2024-09-20', NULL);

-- Consultas de teste e demonstração com melhorias e comentários.

-- Consulta 1: Calcular o total de dias letivos para cada plano de ensino.
-- Esta consulta soma a duração das faixas de dados que são classificadas como 'acadêmicas' 
-- para cada plano de ensino, fornecendo o número total de dias letivos.
SELECT
    p.titulo AS "Plano de Ensino",
    SUM(f.fim - f.inicio + 1) AS "Dias Letivos"
FROM
    plano_ensino p
JOIN
    tipo_dia td ON td.id_plano = p.id_plano
JOIN
    faixa_data f ON f.id_tipo = td.id_tipo
WHERE
    td.academico = TRUE
GROUP BY
    p.titulo
ORDER BY
    p.titulo;

-- Consulta 2: Verificar o status de atividades obrigatórias para um período específico.
-- Esta consulta compara o número de vezes que uma atividade base foi realizada com o número
-- de vezes que ela é requerida, indicando se há pendências.
SELECT
    ab.nome_atividade AS "Atividade Obrigatória",
    ab.vezes_requeridas AS "Vezes Requeridas",
    COUNT(ar.id_evento) AS "Realizadas",
    CASE
        WHEN COUNT(ar.id_evento) < ab.vezes_requeridas THEN 'Pendência'
        ELSE 'Concluído'
    END AS "Status"
FROM
    atividade_base ab
LEFT JOIN
    atividade_realizada ar ON ar.id_base = ab.id_base AND ar.id_periodo = 2024
GROUP BY
    ab.nome_atividade, ab.vezes_requeridas
ORDER BY
    ab.nome_atividade;

-- Consulta 3: Listar faixas de datas não acadêmicas (feriados e recessos).
-- Esta consulta filtra as faixas de datas que não são consideradas acadêmicas e as categoriza
-- como 'Feriado' ou 'Recesso' com base no rótulo do tipo de dia.
SELECT
    f.descricao AS "Descrição da Faixa",
    f.inicio AS "Início",
    f.fim AS "Fim",
    CASE
        WHEN td.rotulo LIKE '%Feriado%' THEN 'Feriado'
        ELSE 'Recesso'
    END AS "Tipo"
FROM
    faixa_data f
JOIN
    tipo_dia td ON td.id_tipo = f.id_tipo
WHERE
    td.academico = FALSE
ORDER BY
    f.inicio;

-- Consulta 4: Identificar atividades realizadas fora do período acadêmico definido.
-- Esta consulta verifica se alguma atividade registrada ocorreu fora das datas de início e fim
-- do período acadêmico ao qual está associada, o que pode indicar um erro de registro.
SELECT
    ar.descricao AS "Atividade",
    ar.inicio AS "Data de Início da Atividade",
    pa.nome_periodo AS "Período Acadêmico Associado",
    pa.data_inicio AS "Início do Período",
    pa.data_fim AS "Fim do Período"
FROM
    atividade_realizada ar
JOIN
    periodo_academico pa ON pa.id_periodo = ar.id_periodo
WHERE
    ar.inicio < pa.data_inicio OR ar.inicio > pa.data_fim
ORDER BY
    ar.inicio;

-- Consulta 5: Analisar dias de semana de dias perdidos e repostos para reposições.
-- Esta consulta extrai o dia da semana (0=Domingo, 6=Sábado) para o dia perdido e o dia reposto
-- em registros de reposição, útil para verificar a consistência dos dias da semana.
SELECT
    r.dia_perdido AS "Dia Perdido",
    r.dia_reposto AS "Dia Reposto",
    EXTRACT(DOW FROM r.dia_perdido) AS "Dia da Semana Perdido (0=Dom)",
    EXTRACT(DOW FROM r.dia_reposto) AS "Dia da Semana Reposto (0=Dom)"
FROM
    reposicao_dia r
WHERE
    r.id_periodo = 2024
ORDER BY
    r.dia_perdido;

-- Melhorias Adicionais Sugeridas:

-- 1. Adicionar índices para otimização de consultas:
-- Índices podem acelerar a recuperação de dados em colunas frequentemente usadas em cláusulas WHERE ou JOIN.
CREATE INDEX idx_plano_ensino_id_periodo ON plano_ensino (id_periodo);
CREATE INDEX idx_tipo_dia_id_plano ON tipo_dia (id_plano);
CREATE INDEX idx_faixa_data_id_tipo ON faixa_data (id_tipo);
CREATE INDEX idx_reposicao_dia_id_periodo ON reposicao_dia (id_periodo);
CREATE INDEX idx_atividade_realizada_id_periodo ON atividade_realizada (id_periodo);
CREATE INDEX idx_atividade_realizada_id_base ON atividade_realizada (id_base);

-- 2. Adicionar uma visão para simplificar a consulta de dias letivos por plano de ensino.
-- Visões são tabelas virtuais que simplificam consultas complexas e podem ser usadas como tabelas reais.
CREATE VIEW dias_letivos_por_plano AS
SELECT
    p.titulo AS plano_ensino_titulo,
    SUM(f.fim - f.inicio + 1) AS total_dias_letivos
FROM
    plano_ensino p
JOIN
    tipo_dia td ON td.id_plano = p.id_plano
JOIN
    faixa_data f ON f.id_tipo = td.id_tipo
WHERE
    td.academico = TRUE
GROUP BY
    p.titulo;

-- Exemplo de uso da visão:
-- SELECT * FROM dias_letivos_por_plano;

-- 3. Adicionar uma função para verificar a validade de um período acadêmico.
-- Funções podem encapsular lógica de negócios e serem reutilizadas em consultas ou outras funções.
CREATE OR REPLACE FUNCTION verificar_periodo_valido(p_id_periodo INT) RETURNS BOOLEAN AS $$
DECLARE
    v_data_inicio DATE;
    v_data_fim DATE;
BEGIN
    SELECT data_inicio, data_fim INTO v_data_inicio, v_data_fim
    FROM periodo_academico
    WHERE id_periodo = p_id_periodo;

    IF v_data_inicio IS NULL THEN
        RETURN FALSE; -- Período não encontrado
    END IF;

    RETURN v_data_inicio < v_data_fim;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT verificar_periodo_valido(2024);
-- SELECT verificar_periodo_valido(9999);

-- 4. Adicionar um gatilho para garantir que a data de reposição não seja anterior à data perdida.
-- Gatilhos são blocos de código que são executados automaticamente em resposta a eventos (INSERT, UPDATE, DELETE).
CREATE OR REPLACE FUNCTION checar_data_reposicao() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.dia_reposto < NEW.dia_perdido THEN
        RAISE EXCEPTION 'A data de reposição (%) não pode ser anterior à data do dia perdido (%).',
                        NEW.dia_reposto, NEW.dia_perdido;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_checar_data_reposicao
BEFORE INSERT OR UPDATE ON reposicao_dia
FOR EACH ROW
EXECUTE FUNCTION checar_data_reposicao();

-- Exemplo de teste do gatilho (tentará inserir e falhará):
-- INSERT INTO reposicao_dia (id_periodo, dia_perdido, dia_reposto) VALUES (2024, '2024-11-20', '2024-11-19');

-- 5. Adicionar uma regra para evitar a exclusão de planos de ensino publicados.
-- Regras (RULES) são uma forma de reescrever consultas, mas são menos flexíveis que gatilhos para validações complexas.
-- Para este caso, um gatilho seria mais robusto, mas a regra é incluída para demonstração.
CREATE RULE no_delete_published_plan AS ON DELETE TO plano_ensino
WHERE OLD.publicado = TRUE
DO INSTEAD
    SELECT RAISE EXCEPTION 'Não é permitido excluir planos de ensino publicados (ID: %).', OLD.id_plano;

-- Exemplo de teste da regra (tentará excluir e falhará):
-- DELETE FROM plano_ensino WHERE id_plano = 1;

-- 6. Adicionar uma função para calcular a duração de um evento em dias.
CREATE OR REPLACE FUNCTION calcular_duracao_evento(p_inicio DATE, p_fim DATE) RETURNS INT AS $$
BEGIN
    RETURN p_fim - p_inicio + 1;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT descricao, inicio, fim, calcular_duracao_evento(inicio, fim) AS duracao_dias FROM atividade_realizada;

-- 7. Adicionar uma visão para listar atividades realizadas com suas durações.
CREATE VIEW atividades_com_duracao AS
SELECT
    ar.descricao,
    ar.inicio,
    ar.fim,
    calcular_duracao_evento(ar.inicio, ar.fim) AS duracao_dias,
    pa.nome_periodo
FROM
    atividade_realizada ar
JOIN
    periodo_academico pa ON ar.id_periodo = pa.id_periodo;

-- Exemplo de uso da visão:
-- SELECT * FROM atividades_com_duracao;

-- 8. Adicionar uma função para obter o nome do dia da semana a partir de uma data.
CREATE OR REPLACE FUNCTION get_nome_dia_semana(p_data DATE) RETURNS VARCHAR AS $$
BEGIN
    RETURN CASE EXTRACT(DOW FROM p_data)
        WHEN 0 THEN 'Domingo'
        WHEN 1 THEN 'Segunda-feira'
        WHEN 2 THEN 'Terça-feira'
        WHEN 3 THEN 'Quarta-feira'
        WHEN 4 THEN 'Quinta-feira'
        WHEN 5 THEN 'Sexta-feira'
        WHEN 6 THEN 'Sábado'
    END;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT dia_perdido, get_nome_dia_semana(dia_perdido) AS dia_semana_perdido FROM reposicao_dia WHERE id_periodo = 2024;

-- 9. Adicionar uma visão para listar reposições com nomes dos dias da semana.
CREATE VIEW reposicoes_com_dias_semana AS
SELECT
    r.dia_perdido,
    get_nome_dia_semana(r.dia_perdido) AS dia_semana_perdido,
    r.dia_reposto,
    get_nome_dia_semana(r.dia_reposto) AS dia_semana_reposto,
    pa.nome_periodo
FROM
    reposicao_dia r
JOIN
    periodo_academico pa ON r.id_periodo = pa.id_periodo;

-- Exemplo de uso da visão:
-- SELECT * FROM reposicoes_com_dias_semana;

-- 10. Adicionar uma função para verificar se uma data está dentro de uma faixa de datas.
CREATE OR REPLACE FUNCTION is_date_in_range(p_date DATE, p_start_date DATE, p_end_date DATE) RETURNS BOOLEAN AS $$
BEGIN
    RETURN p_date BETWEEN p_start_date AND p_end_date;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT descricao, inicio, fim, is_date_in_range('2024-07-15', inicio, fim) AS esta_em_faixa FROM faixa_data;

-- 11. Adicionar uma visão para listar planos de ensino que não estão publicados.
CREATE VIEW planos_nao_publicados AS
SELECT
    id_plano,
    titulo,
    nome_periodo
FROM
    plano_ensino pe
JOIN
    periodo_academico pa ON pe.id_periodo = pa.id_periodo
WHERE
    publicado = FALSE;

-- Exemplo de uso da visão:
-- SELECT * FROM planos_nao_publicados;

-- 12. Adicionar uma função para contar o número de atividades realizadas para uma atividade base específica em um período.
CREATE OR REPLACE FUNCTION contar_atividades_realizadas_base(p_id_base INT, p_id_periodo INT) RETURNS BIGINT AS $$
DECLARE
    v_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM atividade_realizada
    WHERE id_base = p_id_base AND id_periodo = p_id_periodo;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Exemplo de uso da função:
-- SELECT nome_atividade, vezes_requeridas, contar_atividades_realizadas_base(id_base, 2024) AS realizadas_no_periodo FROM atividade_base;

-- 13. Adicionar um gatilho para atualizar automaticamente o status de publicação de um plano de ensino
-- se todos os seus tipos de dia tiverem dias_minimos > 0.
-- Este gatilho é um exemplo mais complexo que pode ser adaptado conforme a lógica de negócio.
CREATE OR REPLACE FUNCTION atualizar_status_publicacao_plano() RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        -- Verifica se todos os tipos de dia associados a este plano têm dias_minimos > 0
        -- e se o plano ainda não está publicado.
        IF NOT EXISTS (
            SELECT 1
            FROM tipo_dia
            WHERE id_plano = NEW.id_plano AND dias_minimos <= 0
        ) AND NEW.publicado = FALSE THEN
            UPDATE plano_ensino
            SET publicado = TRUE
            WHERE id_plano = NEW.id_plano;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Este gatilho seria acionado na tabela tipo_dia, pois é onde os dias_minimos são definidos.
-- CREATE TRIGGER trg_atualizar_publicacao_plano
-- AFTER INSERT OR UPDATE ON tipo_dia
-- FOR EACH ROW
-- EXECUTE FUNCTION atualizar_status_publicacao_plano();

-- Nota: A ativação deste gatilho pode requerer uma revisão da lógica de negócio, pois a publicação
-- de um plano pode depender de múltiplos fatores além dos dias_minimos.

-- Fim das melhorias.

